﻿namespace ScheduleGenerator
{
    partial class AdministratorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.FileMenuStripItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddUserMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GenerateScheduleTab = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl110 = new System.Windows.Forms.Label();
            this.lbl111 = new System.Windows.Forms.Label();
            this.lbl112 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl210 = new System.Windows.Forms.Label();
            this.lbl211 = new System.Windows.Forms.Label();
            this.lbl212 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.lbl37 = new System.Windows.Forms.Label();
            this.lbl38 = new System.Windows.Forms.Label();
            this.lbl39 = new System.Windows.Forms.Label();
            this.lbl310 = new System.Windows.Forms.Label();
            this.lbl311 = new System.Windows.Forms.Label();
            this.lbl312 = new System.Windows.Forms.Label();
            this.lbl41 = new System.Windows.Forms.Label();
            this.lbl42 = new System.Windows.Forms.Label();
            this.lbl43 = new System.Windows.Forms.Label();
            this.lbl44 = new System.Windows.Forms.Label();
            this.lbl45 = new System.Windows.Forms.Label();
            this.lbl46 = new System.Windows.Forms.Label();
            this.lbl47 = new System.Windows.Forms.Label();
            this.lbl48 = new System.Windows.Forms.Label();
            this.lbl49 = new System.Windows.Forms.Label();
            this.lbl410 = new System.Windows.Forms.Label();
            this.lbl411 = new System.Windows.Forms.Label();
            this.lbl412 = new System.Windows.Forms.Label();
            this.lbl51 = new System.Windows.Forms.Label();
            this.lbl52 = new System.Windows.Forms.Label();
            this.lbl53 = new System.Windows.Forms.Label();
            this.lbl54 = new System.Windows.Forms.Label();
            this.lbl55 = new System.Windows.Forms.Label();
            this.lbl56 = new System.Windows.Forms.Label();
            this.lbl57 = new System.Windows.Forms.Label();
            this.lbl58 = new System.Windows.Forms.Label();
            this.lbl59 = new System.Windows.Forms.Label();
            this.lbl510 = new System.Windows.Forms.Label();
            this.lbl511 = new System.Windows.Forms.Label();
            this.lbl62 = new System.Windows.Forms.Label();
            this.lbl61 = new System.Windows.Forms.Label();
            this.lbl63 = new System.Windows.Forms.Label();
            this.lbl64 = new System.Windows.Forms.Label();
            this.lbl65 = new System.Windows.Forms.Label();
            this.lbl66 = new System.Windows.Forms.Label();
            this.lbl512 = new System.Windows.Forms.Label();
            this.lbl67 = new System.Windows.Forms.Label();
            this.lbl68 = new System.Windows.Forms.Label();
            this.lbl69 = new System.Windows.Forms.Label();
            this.lbl610 = new System.Windows.Forms.Label();
            this.lbl611 = new System.Windows.Forms.Label();
            this.lbl612 = new System.Windows.Forms.Label();
            this.lbl71 = new System.Windows.Forms.Label();
            this.lbl72 = new System.Windows.Forms.Label();
            this.lbl73 = new System.Windows.Forms.Label();
            this.lbl74 = new System.Windows.Forms.Label();
            this.lbl75 = new System.Windows.Forms.Label();
            this.lbl76 = new System.Windows.Forms.Label();
            this.lbl77 = new System.Windows.Forms.Label();
            this.lbl78 = new System.Windows.Forms.Label();
            this.lbl79 = new System.Windows.Forms.Label();
            this.lbl710 = new System.Windows.Forms.Label();
            this.lbl711 = new System.Windows.Forms.Label();
            this.lbl712 = new System.Windows.Forms.Label();
            this.GenerateButton = new System.Windows.Forms.Button();
            this.AdminTabControl = new System.Windows.Forms.TabControl();
            this.menuStrip2.SuspendLayout();
            this.GenerateScheduleTab.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.AdminTabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 24);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(818, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Font = new System.Drawing.Font("Times New Roman", 8.25F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileMenuStripItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip2.Size = new System.Drawing.Size(818, 24);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "AdminMenuStrip";
            // 
            // FileMenuStripItem
            // 
            this.FileMenuStripItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddUserMenuItem,
            this.editUserToolStripMenuItem,
            this.ExitMenuItem});
            this.FileMenuStripItem.Name = "FileMenuStripItem";
            this.FileMenuStripItem.Size = new System.Drawing.Size(36, 20);
            this.FileMenuStripItem.Text = "File";
            // 
            // AddUserMenuItem
            // 
            this.AddUserMenuItem.Name = "AddUserMenuItem";
            this.AddUserMenuItem.Size = new System.Drawing.Size(117, 22);
            this.AddUserMenuItem.Text = "Add User";
            this.AddUserMenuItem.Click += new System.EventHandler(this.AddUserMenuItem_Click);
            // 
            // editUserToolStripMenuItem
            // 
            this.editUserToolStripMenuItem.Name = "editUserToolStripMenuItem";
            this.editUserToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.editUserToolStripMenuItem.Text = "Edit User";
            this.editUserToolStripMenuItem.Click += new System.EventHandler(this.editUserToolStripMenuItem_Click);
            // 
            // ExitMenuItem
            // 
            this.ExitMenuItem.Name = "ExitMenuItem";
            this.ExitMenuItem.Size = new System.Drawing.Size(117, 22);
            this.ExitMenuItem.Text = "Exit";
            this.ExitMenuItem.Click += new System.EventHandler(this.ExitMenuItem_Click);
            // 
            // GenerateScheduleTab
            // 
            this.GenerateScheduleTab.Controls.Add(this.tableLayoutPanel1);
            this.GenerateScheduleTab.Controls.Add(this.GenerateButton);
            this.GenerateScheduleTab.Location = new System.Drawing.Point(4, 23);
            this.GenerateScheduleTab.Margin = new System.Windows.Forms.Padding(2);
            this.GenerateScheduleTab.Name = "GenerateScheduleTab";
            this.GenerateScheduleTab.Padding = new System.Windows.Forms.Padding(2);
            this.GenerateScheduleTab.Size = new System.Drawing.Size(801, 412);
            this.GenerateScheduleTab.TabIndex = 1;
            this.GenerateScheduleTab.Text = "Generate Schedule";
            this.GenerateScheduleTab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.DarkGray;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.15361F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30773F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30773F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.95092F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.49693F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.88344F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30772F));
            this.tableLayoutPanel1.Controls.Add(this.label28, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label12, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label13, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label14, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label15, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label16, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label17, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label24, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label26, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label27, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl11, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl12, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl13, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl14, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl15, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl16, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl17, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl18, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl19, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl110, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl111, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl112, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl21, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl22, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl23, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl24, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl25, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl26, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl27, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl28, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl29, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl210, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl211, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl212, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl31, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl32, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl33, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl34, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl35, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl36, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl37, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl38, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl39, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl310, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl311, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl312, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl41, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl42, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl43, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl44, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl45, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl46, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl47, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl48, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl49, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl410, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl411, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl412, 4, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl51, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl52, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl53, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl54, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl55, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl56, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl57, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl58, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl59, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl510, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl511, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl62, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl61, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl63, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl64, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl65, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl66, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl512, 5, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl67, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl68, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl69, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl610, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl611, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl612, 6, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl71, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl72, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl73, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl74, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl75, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl76, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl77, 7, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl78, 7, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl79, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl710, 7, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl711, 7, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl712, 7, 12);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(9, 10);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.60241F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.39759F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(774, 366);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(6, 342);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 12);
            this.label28.TabIndex = 36;
            this.label28.Text = "20:00 - 21:00";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "10:00 - 11:00";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(88, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Sunday";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(186, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Monday";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(285, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Tuesday";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(383, 3);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Wednesday";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(493, 3);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Thursday";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(586, 3);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Friday";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(675, 3);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Saturday";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(5, 85);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "09:00 - 10:00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "11:00 - 12:00";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 158);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 12);
            this.label20.TabIndex = 28;
            this.label20.Text = "12:00 - 13:00";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(6, 181);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 12);
            this.label21.TabIndex = 29;
            this.label21.Text = "13:00 - 14:00";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 204);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 12);
            this.label22.TabIndex = 30;
            this.label22.Text = "14:00 - 15:00";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 227);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 12);
            this.label23.TabIndex = 31;
            this.label23.Text = "15:00 - 16:00";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 250);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 12);
            this.label24.TabIndex = 32;
            this.label24.Text = "16:00 - 17:00";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 273);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 12);
            this.label25.TabIndex = 33;
            this.label25.Text = "17:00 - 18:00";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(6, 296);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 12);
            this.label26.TabIndex = 34;
            this.label26.Text = "18:00 - 19:00";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(6, 319);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 12);
            this.label27.TabIndex = 35;
            this.label27.Text = "19:00 - 20:00";
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Location = new System.Drawing.Point(88, 85);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(23, 13);
            this.lbl11.TabIndex = 37;
            this.lbl11.Text = "NA";
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Location = new System.Drawing.Point(88, 110);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(23, 13);
            this.lbl12.TabIndex = 37;
            this.lbl12.Text = "NA";
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Location = new System.Drawing.Point(88, 135);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(23, 13);
            this.lbl13.TabIndex = 37;
            this.lbl13.Text = "NA";
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Location = new System.Drawing.Point(88, 158);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(23, 13);
            this.lbl14.TabIndex = 37;
            this.lbl14.Text = "NA";
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Location = new System.Drawing.Point(88, 181);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(23, 13);
            this.lbl15.TabIndex = 37;
            this.lbl15.Text = "NA";
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Location = new System.Drawing.Point(88, 204);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(23, 13);
            this.lbl16.TabIndex = 37;
            this.lbl16.Text = "NA";
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Location = new System.Drawing.Point(88, 227);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(23, 13);
            this.lbl17.TabIndex = 37;
            this.lbl17.Text = "NA";
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Location = new System.Drawing.Point(88, 250);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(23, 13);
            this.lbl18.TabIndex = 37;
            this.lbl18.Text = "NA";
            // 
            // lbl19
            // 
            this.lbl19.AutoSize = true;
            this.lbl19.Location = new System.Drawing.Point(88, 273);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(23, 13);
            this.lbl19.TabIndex = 37;
            this.lbl19.Text = "NA";
            // 
            // lbl110
            // 
            this.lbl110.AutoSize = true;
            this.lbl110.Location = new System.Drawing.Point(88, 296);
            this.lbl110.Name = "lbl110";
            this.lbl110.Size = new System.Drawing.Size(23, 13);
            this.lbl110.TabIndex = 37;
            this.lbl110.Text = "NA";
            // 
            // lbl111
            // 
            this.lbl111.AutoSize = true;
            this.lbl111.Location = new System.Drawing.Point(88, 319);
            this.lbl111.Name = "lbl111";
            this.lbl111.Size = new System.Drawing.Size(23, 13);
            this.lbl111.TabIndex = 37;
            this.lbl111.Text = "NA";
            // 
            // lbl112
            // 
            this.lbl112.AutoSize = true;
            this.lbl112.Location = new System.Drawing.Point(88, 342);
            this.lbl112.Name = "lbl112";
            this.lbl112.Size = new System.Drawing.Size(23, 13);
            this.lbl112.TabIndex = 37;
            this.lbl112.Text = "NA";
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.Location = new System.Drawing.Point(186, 85);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(23, 13);
            this.lbl21.TabIndex = 37;
            this.lbl21.Text = "NA";
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Location = new System.Drawing.Point(186, 110);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(23, 13);
            this.lbl22.TabIndex = 37;
            this.lbl22.Text = "NA";
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.Location = new System.Drawing.Point(186, 135);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(23, 13);
            this.lbl23.TabIndex = 37;
            this.lbl23.Text = "NA";
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.Location = new System.Drawing.Point(186, 158);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(23, 13);
            this.lbl24.TabIndex = 37;
            this.lbl24.Text = "NA";
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.Location = new System.Drawing.Point(186, 181);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(23, 13);
            this.lbl25.TabIndex = 37;
            this.lbl25.Text = "NA";
            // 
            // lbl26
            // 
            this.lbl26.AutoSize = true;
            this.lbl26.Location = new System.Drawing.Point(186, 204);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(23, 13);
            this.lbl26.TabIndex = 37;
            this.lbl26.Text = "NA";
            // 
            // lbl27
            // 
            this.lbl27.AutoSize = true;
            this.lbl27.Location = new System.Drawing.Point(186, 227);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(23, 13);
            this.lbl27.TabIndex = 37;
            this.lbl27.Text = "NA";
            // 
            // lbl28
            // 
            this.lbl28.AutoSize = true;
            this.lbl28.Location = new System.Drawing.Point(186, 250);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(23, 13);
            this.lbl28.TabIndex = 37;
            this.lbl28.Text = "NA";
            // 
            // lbl29
            // 
            this.lbl29.AutoSize = true;
            this.lbl29.Location = new System.Drawing.Point(186, 273);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(23, 13);
            this.lbl29.TabIndex = 37;
            this.lbl29.Text = "NA";
            // 
            // lbl210
            // 
            this.lbl210.AutoSize = true;
            this.lbl210.Location = new System.Drawing.Point(186, 296);
            this.lbl210.Name = "lbl210";
            this.lbl210.Size = new System.Drawing.Size(23, 13);
            this.lbl210.TabIndex = 37;
            this.lbl210.Text = "NA";
            // 
            // lbl211
            // 
            this.lbl211.AutoSize = true;
            this.lbl211.Location = new System.Drawing.Point(186, 319);
            this.lbl211.Name = "lbl211";
            this.lbl211.Size = new System.Drawing.Size(23, 13);
            this.lbl211.TabIndex = 37;
            this.lbl211.Text = "NA";
            // 
            // lbl212
            // 
            this.lbl212.AutoSize = true;
            this.lbl212.Location = new System.Drawing.Point(186, 342);
            this.lbl212.Name = "lbl212";
            this.lbl212.Size = new System.Drawing.Size(23, 13);
            this.lbl212.TabIndex = 37;
            this.lbl212.Text = "NA";
            // 
            // lbl31
            // 
            this.lbl31.AutoSize = true;
            this.lbl31.Location = new System.Drawing.Point(285, 85);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(23, 13);
            this.lbl31.TabIndex = 37;
            this.lbl31.Text = "NA";
            // 
            // lbl32
            // 
            this.lbl32.AutoSize = true;
            this.lbl32.Location = new System.Drawing.Point(285, 110);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(23, 13);
            this.lbl32.TabIndex = 37;
            this.lbl32.Text = "NA";
            // 
            // lbl33
            // 
            this.lbl33.AutoSize = true;
            this.lbl33.Location = new System.Drawing.Point(285, 135);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(23, 13);
            this.lbl33.TabIndex = 37;
            this.lbl33.Text = "NA";
            // 
            // lbl34
            // 
            this.lbl34.AutoSize = true;
            this.lbl34.Location = new System.Drawing.Point(285, 158);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(23, 13);
            this.lbl34.TabIndex = 37;
            this.lbl34.Text = "NA";
            // 
            // lbl35
            // 
            this.lbl35.AutoSize = true;
            this.lbl35.Location = new System.Drawing.Point(285, 181);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(23, 13);
            this.lbl35.TabIndex = 37;
            this.lbl35.Text = "NA";
            // 
            // lbl36
            // 
            this.lbl36.AutoSize = true;
            this.lbl36.Location = new System.Drawing.Point(285, 204);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(23, 13);
            this.lbl36.TabIndex = 37;
            this.lbl36.Text = "NA";
            // 
            // lbl37
            // 
            this.lbl37.AutoSize = true;
            this.lbl37.Location = new System.Drawing.Point(285, 227);
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(23, 13);
            this.lbl37.TabIndex = 37;
            this.lbl37.Text = "NA";
            // 
            // lbl38
            // 
            this.lbl38.AutoSize = true;
            this.lbl38.Location = new System.Drawing.Point(285, 250);
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(23, 13);
            this.lbl38.TabIndex = 37;
            this.lbl38.Text = "NA";
            // 
            // lbl39
            // 
            this.lbl39.AutoSize = true;
            this.lbl39.Location = new System.Drawing.Point(285, 273);
            this.lbl39.Name = "lbl39";
            this.lbl39.Size = new System.Drawing.Size(23, 13);
            this.lbl39.TabIndex = 37;
            this.lbl39.Text = "NA";
            // 
            // lbl310
            // 
            this.lbl310.AutoSize = true;
            this.lbl310.Location = new System.Drawing.Point(285, 296);
            this.lbl310.Name = "lbl310";
            this.lbl310.Size = new System.Drawing.Size(23, 13);
            this.lbl310.TabIndex = 37;
            this.lbl310.Text = "NA";
            // 
            // lbl311
            // 
            this.lbl311.AutoSize = true;
            this.lbl311.Location = new System.Drawing.Point(285, 319);
            this.lbl311.Name = "lbl311";
            this.lbl311.Size = new System.Drawing.Size(23, 13);
            this.lbl311.TabIndex = 37;
            this.lbl311.Text = "NA";
            // 
            // lbl312
            // 
            this.lbl312.AutoSize = true;
            this.lbl312.Location = new System.Drawing.Point(285, 342);
            this.lbl312.Name = "lbl312";
            this.lbl312.Size = new System.Drawing.Size(23, 13);
            this.lbl312.TabIndex = 37;
            this.lbl312.Text = "NA";
            // 
            // lbl41
            // 
            this.lbl41.AutoSize = true;
            this.lbl41.Location = new System.Drawing.Point(384, 85);
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(23, 13);
            this.lbl41.TabIndex = 37;
            this.lbl41.Text = "NA";
            // 
            // lbl42
            // 
            this.lbl42.AutoSize = true;
            this.lbl42.Location = new System.Drawing.Point(384, 110);
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(23, 13);
            this.lbl42.TabIndex = 37;
            this.lbl42.Text = "NA";
            // 
            // lbl43
            // 
            this.lbl43.AutoSize = true;
            this.lbl43.Location = new System.Drawing.Point(384, 135);
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(23, 13);
            this.lbl43.TabIndex = 37;
            this.lbl43.Text = "NA";
            // 
            // lbl44
            // 
            this.lbl44.AutoSize = true;
            this.lbl44.Location = new System.Drawing.Point(384, 158);
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(23, 13);
            this.lbl44.TabIndex = 37;
            this.lbl44.Text = "NA";
            // 
            // lbl45
            // 
            this.lbl45.AutoSize = true;
            this.lbl45.Location = new System.Drawing.Point(384, 181);
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(23, 13);
            this.lbl45.TabIndex = 37;
            this.lbl45.Text = "NA";
            // 
            // lbl46
            // 
            this.lbl46.AutoSize = true;
            this.lbl46.Location = new System.Drawing.Point(384, 204);
            this.lbl46.Name = "lbl46";
            this.lbl46.Size = new System.Drawing.Size(23, 13);
            this.lbl46.TabIndex = 37;
            this.lbl46.Text = "NA";
            // 
            // lbl47
            // 
            this.lbl47.AutoSize = true;
            this.lbl47.Location = new System.Drawing.Point(384, 227);
            this.lbl47.Name = "lbl47";
            this.lbl47.Size = new System.Drawing.Size(23, 13);
            this.lbl47.TabIndex = 37;
            this.lbl47.Text = "NA";
            // 
            // lbl48
            // 
            this.lbl48.AutoSize = true;
            this.lbl48.Location = new System.Drawing.Point(384, 250);
            this.lbl48.Name = "lbl48";
            this.lbl48.Size = new System.Drawing.Size(23, 13);
            this.lbl48.TabIndex = 37;
            this.lbl48.Text = "NA";
            // 
            // lbl49
            // 
            this.lbl49.AutoSize = true;
            this.lbl49.Location = new System.Drawing.Point(384, 273);
            this.lbl49.Name = "lbl49";
            this.lbl49.Size = new System.Drawing.Size(23, 13);
            this.lbl49.TabIndex = 37;
            this.lbl49.Text = "NA";
            // 
            // lbl410
            // 
            this.lbl410.AutoSize = true;
            this.lbl410.Location = new System.Drawing.Point(384, 296);
            this.lbl410.Name = "lbl410";
            this.lbl410.Size = new System.Drawing.Size(23, 13);
            this.lbl410.TabIndex = 37;
            this.lbl410.Text = "NA";
            // 
            // lbl411
            // 
            this.lbl411.AutoSize = true;
            this.lbl411.Location = new System.Drawing.Point(384, 319);
            this.lbl411.Name = "lbl411";
            this.lbl411.Size = new System.Drawing.Size(23, 13);
            this.lbl411.TabIndex = 37;
            this.lbl411.Text = "NA";
            // 
            // lbl412
            // 
            this.lbl412.AutoSize = true;
            this.lbl412.Location = new System.Drawing.Point(384, 342);
            this.lbl412.Name = "lbl412";
            this.lbl412.Size = new System.Drawing.Size(23, 13);
            this.lbl412.TabIndex = 37;
            this.lbl412.Text = "NA";
            // 
            // lbl51
            // 
            this.lbl51.AutoSize = true;
            this.lbl51.Location = new System.Drawing.Point(494, 85);
            this.lbl51.Name = "lbl51";
            this.lbl51.Size = new System.Drawing.Size(23, 13);
            this.lbl51.TabIndex = 37;
            this.lbl51.Text = "NA";
            // 
            // lbl52
            // 
            this.lbl52.AutoSize = true;
            this.lbl52.Location = new System.Drawing.Point(494, 110);
            this.lbl52.Name = "lbl52";
            this.lbl52.Size = new System.Drawing.Size(23, 13);
            this.lbl52.TabIndex = 37;
            this.lbl52.Text = "NA";
            // 
            // lbl53
            // 
            this.lbl53.AutoSize = true;
            this.lbl53.Location = new System.Drawing.Point(494, 135);
            this.lbl53.Name = "lbl53";
            this.lbl53.Size = new System.Drawing.Size(23, 13);
            this.lbl53.TabIndex = 37;
            this.lbl53.Text = "NA";
            // 
            // lbl54
            // 
            this.lbl54.AutoSize = true;
            this.lbl54.Location = new System.Drawing.Point(494, 158);
            this.lbl54.Name = "lbl54";
            this.lbl54.Size = new System.Drawing.Size(23, 13);
            this.lbl54.TabIndex = 37;
            this.lbl54.Text = "NA";
            // 
            // lbl55
            // 
            this.lbl55.AutoSize = true;
            this.lbl55.Location = new System.Drawing.Point(494, 181);
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(23, 13);
            this.lbl55.TabIndex = 37;
            this.lbl55.Text = "NA";
            // 
            // lbl56
            // 
            this.lbl56.AutoSize = true;
            this.lbl56.Location = new System.Drawing.Point(494, 204);
            this.lbl56.Name = "lbl56";
            this.lbl56.Size = new System.Drawing.Size(23, 13);
            this.lbl56.TabIndex = 37;
            this.lbl56.Text = "NA";
            // 
            // lbl57
            // 
            this.lbl57.AutoSize = true;
            this.lbl57.Location = new System.Drawing.Point(494, 227);
            this.lbl57.Name = "lbl57";
            this.lbl57.Size = new System.Drawing.Size(23, 13);
            this.lbl57.TabIndex = 37;
            this.lbl57.Text = "NA";
            // 
            // lbl58
            // 
            this.lbl58.AutoSize = true;
            this.lbl58.Location = new System.Drawing.Point(494, 250);
            this.lbl58.Name = "lbl58";
            this.lbl58.Size = new System.Drawing.Size(23, 13);
            this.lbl58.TabIndex = 37;
            this.lbl58.Text = "NA";
            // 
            // lbl59
            // 
            this.lbl59.AutoSize = true;
            this.lbl59.Location = new System.Drawing.Point(494, 273);
            this.lbl59.Name = "lbl59";
            this.lbl59.Size = new System.Drawing.Size(23, 13);
            this.lbl59.TabIndex = 37;
            this.lbl59.Text = "NA";
            // 
            // lbl510
            // 
            this.lbl510.AutoSize = true;
            this.lbl510.Location = new System.Drawing.Point(494, 296);
            this.lbl510.Name = "lbl510";
            this.lbl510.Size = new System.Drawing.Size(23, 13);
            this.lbl510.TabIndex = 37;
            this.lbl510.Text = "NA";
            // 
            // lbl511
            // 
            this.lbl511.AutoSize = true;
            this.lbl511.Location = new System.Drawing.Point(494, 319);
            this.lbl511.Name = "lbl511";
            this.lbl511.Size = new System.Drawing.Size(23, 13);
            this.lbl511.TabIndex = 37;
            this.lbl511.Text = "NA";
            // 
            // lbl62
            // 
            this.lbl62.AutoSize = true;
            this.lbl62.Location = new System.Drawing.Point(587, 110);
            this.lbl62.Name = "lbl62";
            this.lbl62.Size = new System.Drawing.Size(23, 13);
            this.lbl62.TabIndex = 37;
            this.lbl62.Text = "NA";
            // 
            // lbl61
            // 
            this.lbl61.AutoSize = true;
            this.lbl61.Location = new System.Drawing.Point(587, 85);
            this.lbl61.Name = "lbl61";
            this.lbl61.Size = new System.Drawing.Size(23, 13);
            this.lbl61.TabIndex = 37;
            this.lbl61.Text = "NA";
            // 
            // lbl63
            // 
            this.lbl63.AutoSize = true;
            this.lbl63.Location = new System.Drawing.Point(587, 135);
            this.lbl63.Name = "lbl63";
            this.lbl63.Size = new System.Drawing.Size(23, 13);
            this.lbl63.TabIndex = 37;
            this.lbl63.Text = "NA";
            // 
            // lbl64
            // 
            this.lbl64.AutoSize = true;
            this.lbl64.Location = new System.Drawing.Point(587, 158);
            this.lbl64.Name = "lbl64";
            this.lbl64.Size = new System.Drawing.Size(23, 13);
            this.lbl64.TabIndex = 37;
            this.lbl64.Text = "NA";
            // 
            // lbl65
            // 
            this.lbl65.AutoSize = true;
            this.lbl65.Location = new System.Drawing.Point(587, 181);
            this.lbl65.Name = "lbl65";
            this.lbl65.Size = new System.Drawing.Size(23, 13);
            this.lbl65.TabIndex = 37;
            this.lbl65.Text = "NA";
            // 
            // lbl66
            // 
            this.lbl66.AutoSize = true;
            this.lbl66.Location = new System.Drawing.Point(587, 204);
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(23, 13);
            this.lbl66.TabIndex = 37;
            this.lbl66.Text = "NA";
            // 
            // lbl512
            // 
            this.lbl512.AutoSize = true;
            this.lbl512.Location = new System.Drawing.Point(494, 342);
            this.lbl512.Name = "lbl512";
            this.lbl512.Size = new System.Drawing.Size(23, 13);
            this.lbl512.TabIndex = 37;
            this.lbl512.Text = "NA";
            // 
            // lbl67
            // 
            this.lbl67.AutoSize = true;
            this.lbl67.Location = new System.Drawing.Point(587, 227);
            this.lbl67.Name = "lbl67";
            this.lbl67.Size = new System.Drawing.Size(23, 13);
            this.lbl67.TabIndex = 37;
            this.lbl67.Text = "NA";
            // 
            // lbl68
            // 
            this.lbl68.AutoSize = true;
            this.lbl68.Location = new System.Drawing.Point(587, 250);
            this.lbl68.Name = "lbl68";
            this.lbl68.Size = new System.Drawing.Size(23, 13);
            this.lbl68.TabIndex = 37;
            this.lbl68.Text = "NA";
            // 
            // lbl69
            // 
            this.lbl69.AutoSize = true;
            this.lbl69.Location = new System.Drawing.Point(587, 273);
            this.lbl69.Name = "lbl69";
            this.lbl69.Size = new System.Drawing.Size(23, 13);
            this.lbl69.TabIndex = 37;
            this.lbl69.Text = "NA";
            // 
            // lbl610
            // 
            this.lbl610.AutoSize = true;
            this.lbl610.Location = new System.Drawing.Point(587, 296);
            this.lbl610.Name = "lbl610";
            this.lbl610.Size = new System.Drawing.Size(23, 13);
            this.lbl610.TabIndex = 37;
            this.lbl610.Text = "NA";
            // 
            // lbl611
            // 
            this.lbl611.AutoSize = true;
            this.lbl611.Location = new System.Drawing.Point(587, 319);
            this.lbl611.Name = "lbl611";
            this.lbl611.Size = new System.Drawing.Size(23, 13);
            this.lbl611.TabIndex = 37;
            this.lbl611.Text = "NA";
            // 
            // lbl612
            // 
            this.lbl612.AutoSize = true;
            this.lbl612.Location = new System.Drawing.Point(587, 342);
            this.lbl612.Name = "lbl612";
            this.lbl612.Size = new System.Drawing.Size(23, 13);
            this.lbl612.TabIndex = 37;
            this.lbl612.Text = "NA";
            // 
            // lbl71
            // 
            this.lbl71.AutoSize = true;
            this.lbl71.Location = new System.Drawing.Point(676, 85);
            this.lbl71.Name = "lbl71";
            this.lbl71.Size = new System.Drawing.Size(23, 13);
            this.lbl71.TabIndex = 37;
            this.lbl71.Text = "NA";
            // 
            // lbl72
            // 
            this.lbl72.AutoSize = true;
            this.lbl72.Location = new System.Drawing.Point(676, 110);
            this.lbl72.Name = "lbl72";
            this.lbl72.Size = new System.Drawing.Size(23, 13);
            this.lbl72.TabIndex = 37;
            this.lbl72.Text = "NA";
            // 
            // lbl73
            // 
            this.lbl73.AutoSize = true;
            this.lbl73.Location = new System.Drawing.Point(676, 135);
            this.lbl73.Name = "lbl73";
            this.lbl73.Size = new System.Drawing.Size(23, 13);
            this.lbl73.TabIndex = 37;
            this.lbl73.Text = "NA";
            // 
            // lbl74
            // 
            this.lbl74.AutoSize = true;
            this.lbl74.Location = new System.Drawing.Point(676, 158);
            this.lbl74.Name = "lbl74";
            this.lbl74.Size = new System.Drawing.Size(23, 13);
            this.lbl74.TabIndex = 37;
            this.lbl74.Text = "NA";
            // 
            // lbl75
            // 
            this.lbl75.AutoSize = true;
            this.lbl75.Location = new System.Drawing.Point(676, 181);
            this.lbl75.Name = "lbl75";
            this.lbl75.Size = new System.Drawing.Size(23, 13);
            this.lbl75.TabIndex = 37;
            this.lbl75.Text = "NA";
            // 
            // lbl76
            // 
            this.lbl76.AutoSize = true;
            this.lbl76.Location = new System.Drawing.Point(676, 204);
            this.lbl76.Name = "lbl76";
            this.lbl76.Size = new System.Drawing.Size(23, 13);
            this.lbl76.TabIndex = 37;
            this.lbl76.Text = "NA";
            // 
            // lbl77
            // 
            this.lbl77.AutoSize = true;
            this.lbl77.Location = new System.Drawing.Point(676, 227);
            this.lbl77.Name = "lbl77";
            this.lbl77.Size = new System.Drawing.Size(23, 13);
            this.lbl77.TabIndex = 37;
            this.lbl77.Text = "NA";
            // 
            // lbl78
            // 
            this.lbl78.AutoSize = true;
            this.lbl78.Location = new System.Drawing.Point(676, 250);
            this.lbl78.Name = "lbl78";
            this.lbl78.Size = new System.Drawing.Size(23, 13);
            this.lbl78.TabIndex = 37;
            this.lbl78.Text = "NA";
            // 
            // lbl79
            // 
            this.lbl79.AutoSize = true;
            this.lbl79.Location = new System.Drawing.Point(676, 273);
            this.lbl79.Name = "lbl79";
            this.lbl79.Size = new System.Drawing.Size(23, 13);
            this.lbl79.TabIndex = 37;
            this.lbl79.Text = "NA";
            // 
            // lbl710
            // 
            this.lbl710.AutoSize = true;
            this.lbl710.Location = new System.Drawing.Point(676, 296);
            this.lbl710.Name = "lbl710";
            this.lbl710.Size = new System.Drawing.Size(23, 13);
            this.lbl710.TabIndex = 37;
            this.lbl710.Text = "NA";
            // 
            // lbl711
            // 
            this.lbl711.AutoSize = true;
            this.lbl711.Location = new System.Drawing.Point(676, 319);
            this.lbl711.Name = "lbl711";
            this.lbl711.Size = new System.Drawing.Size(23, 13);
            this.lbl711.TabIndex = 37;
            this.lbl711.Text = "NA";
            // 
            // lbl712
            // 
            this.lbl712.AutoSize = true;
            this.lbl712.Location = new System.Drawing.Point(676, 342);
            this.lbl712.Name = "lbl712";
            this.lbl712.Size = new System.Drawing.Size(23, 13);
            this.lbl712.TabIndex = 37;
            this.lbl712.Text = "NA";
            // 
            // GenerateButton
            // 
            this.GenerateButton.Location = new System.Drawing.Point(350, 388);
            this.GenerateButton.Margin = new System.Windows.Forms.Padding(2);
            this.GenerateButton.Name = "GenerateButton";
            this.GenerateButton.Size = new System.Drawing.Size(88, 19);
            this.GenerateButton.TabIndex = 2;
            this.GenerateButton.Text = "Generate";
            this.GenerateButton.UseVisualStyleBackColor = true;
            this.GenerateButton.Click += new System.EventHandler(this.GenerateButton_Click);
            // 
            // AdminTabControl
            // 
            this.AdminTabControl.Controls.Add(this.GenerateScheduleTab);
            this.AdminTabControl.Font = new System.Drawing.Font("Times New Roman", 8.25F);
            this.AdminTabControl.Location = new System.Drawing.Point(9, 25);
            this.AdminTabControl.Margin = new System.Windows.Forms.Padding(2);
            this.AdminTabControl.Name = "AdminTabControl";
            this.AdminTabControl.SelectedIndex = 0;
            this.AdminTabControl.Size = new System.Drawing.Size(809, 439);
            this.AdminTabControl.TabIndex = 2;
            // 
            // AdministratorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 466);
            this.Controls.Add(this.AdminTabControl);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AdministratorForm";
            this.Text = "Administrator Name";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.GenerateScheduleTab.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.AdminTabControl.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem FileMenuStripItem;
        private System.Windows.Forms.ToolStripMenuItem AddUserMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ExitMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editUserToolStripMenuItem;
        private System.Windows.Forms.TabPage GenerateScheduleTab;
        private System.Windows.Forms.Button GenerateButton;
        private System.Windows.Forms.TabControl AdminTabControl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl110;
        private System.Windows.Forms.Label lbl111;
        private System.Windows.Forms.Label lbl112;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl210;
        private System.Windows.Forms.Label lbl211;
        private System.Windows.Forms.Label lbl212;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label lbl37;
        private System.Windows.Forms.Label lbl38;
        private System.Windows.Forms.Label lbl39;
        private System.Windows.Forms.Label lbl310;
        private System.Windows.Forms.Label lbl311;
        private System.Windows.Forms.Label lbl312;
        private System.Windows.Forms.Label lbl41;
        private System.Windows.Forms.Label lbl42;
        private System.Windows.Forms.Label lbl43;
        private System.Windows.Forms.Label lbl44;
        private System.Windows.Forms.Label lbl45;
        private System.Windows.Forms.Label lbl46;
        private System.Windows.Forms.Label lbl47;
        private System.Windows.Forms.Label lbl48;
        private System.Windows.Forms.Label lbl49;
        private System.Windows.Forms.Label lbl410;
        private System.Windows.Forms.Label lbl411;
        private System.Windows.Forms.Label lbl412;
        private System.Windows.Forms.Label lbl51;
        private System.Windows.Forms.Label lbl52;
        private System.Windows.Forms.Label lbl53;
        private System.Windows.Forms.Label lbl54;
        private System.Windows.Forms.Label lbl55;
        private System.Windows.Forms.Label lbl56;
        private System.Windows.Forms.Label lbl57;
        private System.Windows.Forms.Label lbl58;
        private System.Windows.Forms.Label lbl59;
        private System.Windows.Forms.Label lbl510;
        private System.Windows.Forms.Label lbl511;
        private System.Windows.Forms.Label lbl62;
        private System.Windows.Forms.Label lbl61;
        private System.Windows.Forms.Label lbl63;
        private System.Windows.Forms.Label lbl64;
        private System.Windows.Forms.Label lbl65;
        private System.Windows.Forms.Label lbl66;
        private System.Windows.Forms.Label lbl512;
        private System.Windows.Forms.Label lbl67;
        private System.Windows.Forms.Label lbl68;
        private System.Windows.Forms.Label lbl69;
        private System.Windows.Forms.Label lbl610;
        private System.Windows.Forms.Label lbl611;
        private System.Windows.Forms.Label lbl612;
        private System.Windows.Forms.Label lbl71;
        private System.Windows.Forms.Label lbl72;
        private System.Windows.Forms.Label lbl73;
        private System.Windows.Forms.Label lbl74;
        private System.Windows.Forms.Label lbl75;
        private System.Windows.Forms.Label lbl76;
        private System.Windows.Forms.Label lbl77;
        private System.Windows.Forms.Label lbl78;
        private System.Windows.Forms.Label lbl79;
        private System.Windows.Forms.Label lbl710;
        private System.Windows.Forms.Label lbl711;
        private System.Windows.Forms.Label lbl712;
    }
}