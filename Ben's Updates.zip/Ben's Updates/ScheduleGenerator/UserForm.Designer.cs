﻿namespace ScheduleGenerator
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserMenuStrip = new System.Windows.Forms.MenuStrip();
            this.FileMenuStripItem = new System.Windows.Forms.ToolStripMenuItem();
            this.askOffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewScheduleTab = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.AvailabilityTab = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.checkBox36 = new System.Windows.Forms.CheckBox();
            this.checkBox37 = new System.Windows.Forms.CheckBox();
            this.checkBox38 = new System.Windows.Forms.CheckBox();
            this.checkBox39 = new System.Windows.Forms.CheckBox();
            this.checkBox40 = new System.Windows.Forms.CheckBox();
            this.checkBox41 = new System.Windows.Forms.CheckBox();
            this.checkBox42 = new System.Windows.Forms.CheckBox();
            this.checkBox43 = new System.Windows.Forms.CheckBox();
            this.checkBox44 = new System.Windows.Forms.CheckBox();
            this.checkBox45 = new System.Windows.Forms.CheckBox();
            this.checkBox46 = new System.Windows.Forms.CheckBox();
            this.checkBox47 = new System.Windows.Forms.CheckBox();
            this.checkBox48 = new System.Windows.Forms.CheckBox();
            this.checkBox49 = new System.Windows.Forms.CheckBox();
            this.checkBox50 = new System.Windows.Forms.CheckBox();
            this.checkBox51 = new System.Windows.Forms.CheckBox();
            this.checkBox52 = new System.Windows.Forms.CheckBox();
            this.checkBox53 = new System.Windows.Forms.CheckBox();
            this.checkBox54 = new System.Windows.Forms.CheckBox();
            this.checkBox55 = new System.Windows.Forms.CheckBox();
            this.checkBox56 = new System.Windows.Forms.CheckBox();
            this.checkBox57 = new System.Windows.Forms.CheckBox();
            this.checkBox58 = new System.Windows.Forms.CheckBox();
            this.checkBox59 = new System.Windows.Forms.CheckBox();
            this.checkBox60 = new System.Windows.Forms.CheckBox();
            this.checkBox61 = new System.Windows.Forms.CheckBox();
            this.checkBox62 = new System.Windows.Forms.CheckBox();
            this.checkBox63 = new System.Windows.Forms.CheckBox();
            this.checkBox64 = new System.Windows.Forms.CheckBox();
            this.checkBox65 = new System.Windows.Forms.CheckBox();
            this.checkBox66 = new System.Windows.Forms.CheckBox();
            this.checkBox67 = new System.Windows.Forms.CheckBox();
            this.checkBox68 = new System.Windows.Forms.CheckBox();
            this.checkBox69 = new System.Windows.Forms.CheckBox();
            this.checkBox70 = new System.Windows.Forms.CheckBox();
            this.checkBox71 = new System.Windows.Forms.CheckBox();
            this.checkBox72 = new System.Windows.Forms.CheckBox();
            this.checkBox73 = new System.Windows.Forms.CheckBox();
            this.checkBox74 = new System.Windows.Forms.CheckBox();
            this.checkBox75 = new System.Windows.Forms.CheckBox();
            this.checkBox76 = new System.Windows.Forms.CheckBox();
            this.checkBox77 = new System.Windows.Forms.CheckBox();
            this.checkBox78 = new System.Windows.Forms.CheckBox();
            this.checkBox79 = new System.Windows.Forms.CheckBox();
            this.checkBox80 = new System.Windows.Forms.CheckBox();
            this.checkBox81 = new System.Windows.Forms.CheckBox();
            this.checkBox82 = new System.Windows.Forms.CheckBox();
            this.checkBox83 = new System.Windows.Forms.CheckBox();
            this.checkBox84 = new System.Windows.Forms.CheckBox();
            this.AvailabilityButton = new System.Windows.Forms.Button();
            this.UserTabControl = new System.Windows.Forms.TabControl();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lbl110 = new System.Windows.Forms.Label();
            this.lbl111 = new System.Windows.Forms.Label();
            this.lbl112 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl210 = new System.Windows.Forms.Label();
            this.lbl211 = new System.Windows.Forms.Label();
            this.lbl212 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.lbl37 = new System.Windows.Forms.Label();
            this.lbl38 = new System.Windows.Forms.Label();
            this.lbl39 = new System.Windows.Forms.Label();
            this.lbl310 = new System.Windows.Forms.Label();
            this.lbl311 = new System.Windows.Forms.Label();
            this.lbl312 = new System.Windows.Forms.Label();
            this.lbl41 = new System.Windows.Forms.Label();
            this.lbl42 = new System.Windows.Forms.Label();
            this.lbl43 = new System.Windows.Forms.Label();
            this.lbl44 = new System.Windows.Forms.Label();
            this.lbl45 = new System.Windows.Forms.Label();
            this.lbl46 = new System.Windows.Forms.Label();
            this.lbl47 = new System.Windows.Forms.Label();
            this.lbl48 = new System.Windows.Forms.Label();
            this.lbl49 = new System.Windows.Forms.Label();
            this.lbl410 = new System.Windows.Forms.Label();
            this.lbl411 = new System.Windows.Forms.Label();
            this.lbl412 = new System.Windows.Forms.Label();
            this.lbl51 = new System.Windows.Forms.Label();
            this.lbl52 = new System.Windows.Forms.Label();
            this.lbl53 = new System.Windows.Forms.Label();
            this.lbl54 = new System.Windows.Forms.Label();
            this.lbl55 = new System.Windows.Forms.Label();
            this.lbl56 = new System.Windows.Forms.Label();
            this.lbl57 = new System.Windows.Forms.Label();
            this.lbl58 = new System.Windows.Forms.Label();
            this.lbl59 = new System.Windows.Forms.Label();
            this.lbl510 = new System.Windows.Forms.Label();
            this.lbl511 = new System.Windows.Forms.Label();
            this.lbl62 = new System.Windows.Forms.Label();
            this.lbl61 = new System.Windows.Forms.Label();
            this.lbl63 = new System.Windows.Forms.Label();
            this.lbl64 = new System.Windows.Forms.Label();
            this.lbl65 = new System.Windows.Forms.Label();
            this.lbl66 = new System.Windows.Forms.Label();
            this.lbl512 = new System.Windows.Forms.Label();
            this.lbl67 = new System.Windows.Forms.Label();
            this.lbl68 = new System.Windows.Forms.Label();
            this.lbl69 = new System.Windows.Forms.Label();
            this.lbl610 = new System.Windows.Forms.Label();
            this.lbl611 = new System.Windows.Forms.Label();
            this.lbl612 = new System.Windows.Forms.Label();
            this.lbl71 = new System.Windows.Forms.Label();
            this.lbl72 = new System.Windows.Forms.Label();
            this.lbl73 = new System.Windows.Forms.Label();
            this.lbl74 = new System.Windows.Forms.Label();
            this.lbl75 = new System.Windows.Forms.Label();
            this.lbl76 = new System.Windows.Forms.Label();
            this.lbl77 = new System.Windows.Forms.Label();
            this.lbl78 = new System.Windows.Forms.Label();
            this.lbl79 = new System.Windows.Forms.Label();
            this.lbl710 = new System.Windows.Forms.Label();
            this.lbl711 = new System.Windows.Forms.Label();
            this.lbl712 = new System.Windows.Forms.Label();
            this.UserMenuStrip.SuspendLayout();
            this.ViewScheduleTab.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.AvailabilityTab.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.UserTabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // UserMenuStrip
            // 
            this.UserMenuStrip.Font = new System.Drawing.Font("Times New Roman", 8.25F);
            this.UserMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.UserMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileMenuStripItem});
            this.UserMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.UserMenuStrip.Name = "UserMenuStrip";
            this.UserMenuStrip.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.UserMenuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.UserMenuStrip.Size = new System.Drawing.Size(768, 24);
            this.UserMenuStrip.TabIndex = 0;
            this.UserMenuStrip.Text = "menuStrip1";
            // 
            // FileMenuStripItem
            // 
            this.FileMenuStripItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.askOffToolStripMenuItem,
            this.ExitMenuItem});
            this.FileMenuStripItem.Name = "FileMenuStripItem";
            this.FileMenuStripItem.Size = new System.Drawing.Size(36, 20);
            this.FileMenuStripItem.Text = "File";
            // 
            // askOffToolStripMenuItem
            // 
            this.askOffToolStripMenuItem.Name = "askOffToolStripMenuItem";
            this.askOffToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.askOffToolStripMenuItem.Text = "Ask Off";
            this.askOffToolStripMenuItem.Click += new System.EventHandler(this.askOffToolStripMenuItem_Click);
            // 
            // ExitMenuItem
            // 
            this.ExitMenuItem.Name = "ExitMenuItem";
            this.ExitMenuItem.Size = new System.Drawing.Size(111, 22);
            this.ExitMenuItem.Text = "Exit";
            this.ExitMenuItem.Click += new System.EventHandler(this.ExitMenuItem_Click);
            // 
            // ViewScheduleTab
            // 
            this.ViewScheduleTab.Controls.Add(this.tableLayoutPanel1);
            this.ViewScheduleTab.Location = new System.Drawing.Point(4, 23);
            this.ViewScheduleTab.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ViewScheduleTab.Name = "ViewScheduleTab";
            this.ViewScheduleTab.Padding = new System.Windows.Forms.Padding(2);
            this.ViewScheduleTab.Size = new System.Drawing.Size(749, 414);
            this.ViewScheduleTab.TabIndex = 2;
            this.ViewScheduleTab.Text = "View Schedule";
            this.ViewScheduleTab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.DarkGray;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.15361F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30773F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30773F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.95092F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.49693F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.88344F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30772F));
            this.tableLayoutPanel1.Controls.Add(this.label28, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label12, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label13, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label14, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label15, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label16, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label17, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.label19, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label24, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label26, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label27, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl11, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl12, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl13, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl14, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl15, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl16, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl17, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl18, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl19, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl110, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl111, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl112, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl21, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl22, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl23, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl24, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl25, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl26, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl27, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl28, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl29, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl210, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl211, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl212, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl31, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl32, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl33, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl34, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl35, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl36, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl37, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl38, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl39, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl310, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl311, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl312, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl41, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl42, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl43, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl44, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl45, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl46, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl47, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl48, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl49, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl410, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl411, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl412, 4, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl51, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl52, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl53, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl54, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl55, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl56, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl57, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl58, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl59, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl510, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl511, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl62, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl61, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl63, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl64, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl65, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl66, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl512, 5, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl67, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl68, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl69, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl610, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl611, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl612, 6, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbl71, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl72, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl73, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl74, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl75, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl76, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl77, 7, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl78, 7, 8);
            this.tableLayoutPanel1.Controls.Add(this.lbl79, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.lbl710, 7, 10);
            this.tableLayoutPanel1.Controls.Add(this.lbl711, 7, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbl712, 7, 12);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 13);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.60241F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.39759F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(739, 366);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(6, 342);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 12);
            this.label28.TabIndex = 36;
            this.label28.Text = "20:00 - 21:00";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "10:00 - 11:00";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(88, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Sunday";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(181, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Monday";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(275, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Tuesday";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(368, 3);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Wednesday";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(472, 3);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Thursday";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(560, 3);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Friday";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(645, 3);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Saturday";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(5, 85);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "09:00 - 10:00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "11:00 - 12:00";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 158);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 12);
            this.label20.TabIndex = 28;
            this.label20.Text = "12:00 - 13:00";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(6, 181);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 12);
            this.label21.TabIndex = 29;
            this.label21.Text = "13:00 - 14:00";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 204);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 12);
            this.label22.TabIndex = 30;
            this.label22.Text = "14:00 - 15:00";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 227);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 12);
            this.label23.TabIndex = 31;
            this.label23.Text = "15:00 - 16:00";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 250);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 12);
            this.label24.TabIndex = 32;
            this.label24.Text = "16:00 - 17:00";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 273);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 12);
            this.label25.TabIndex = 33;
            this.label25.Text = "17:00 - 18:00";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(6, 296);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 12);
            this.label26.TabIndex = 34;
            this.label26.Text = "18:00 - 19:00";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(6, 319);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 12);
            this.label27.TabIndex = 35;
            this.label27.Text = "19:00 - 20:00";
            // 
            // AvailabilityTab
            // 
            this.AvailabilityTab.Controls.Add(this.tableLayoutPanel2);
            this.AvailabilityTab.Controls.Add(this.AvailabilityButton);
            this.AvailabilityTab.Location = new System.Drawing.Point(4, 23);
            this.AvailabilityTab.Margin = new System.Windows.Forms.Padding(2);
            this.AvailabilityTab.Name = "AvailabilityTab";
            this.AvailabilityTab.Padding = new System.Windows.Forms.Padding(2);
            this.AvailabilityTab.Size = new System.Drawing.Size(749, 414);
            this.AvailabilityTab.TabIndex = 0;
            this.AvailabilityTab.Text = "Availability";
            this.AvailabilityTab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.DarkGray;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel2.ColumnCount = 8;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.15361F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30773F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30773F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.95092F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.49693F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.88344F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.30772F));
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label4, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label5, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.label7, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label9, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.label10, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.label29, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label30, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label31, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label33, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label34, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.label35, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label36, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.label37, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.label38, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.checkBox3, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox4, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox5, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox6, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox7, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox8, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox9, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox10, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox11, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox12, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox13, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox14, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.checkBox15, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox16, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox17, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox18, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox19, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox20, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox21, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox22, 2, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox23, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox24, 2, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox25, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox26, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.checkBox27, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox28, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox29, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox30, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox31, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox32, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox33, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox34, 3, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox35, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox36, 3, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox37, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox38, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.checkBox39, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox40, 4, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox41, 4, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox42, 4, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox43, 4, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox44, 4, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox45, 4, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox46, 4, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox47, 4, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox48, 4, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox49, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox50, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.checkBox51, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox52, 5, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox53, 5, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox54, 5, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox55, 5, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox56, 5, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox57, 5, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox58, 5, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox59, 5, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox60, 5, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox61, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox62, 6, 2);
            this.tableLayoutPanel2.Controls.Add(this.checkBox63, 6, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox64, 6, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox65, 6, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox66, 6, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox67, 6, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox68, 6, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox69, 6, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox70, 6, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox71, 6, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox72, 6, 12);
            this.tableLayoutPanel2.Controls.Add(this.checkBox73, 7, 2);
            this.tableLayoutPanel2.Controls.Add(this.checkBox74, 7, 1);
            this.tableLayoutPanel2.Controls.Add(this.checkBox75, 7, 3);
            this.tableLayoutPanel2.Controls.Add(this.checkBox76, 7, 4);
            this.tableLayoutPanel2.Controls.Add(this.checkBox77, 7, 5);
            this.tableLayoutPanel2.Controls.Add(this.checkBox78, 7, 6);
            this.tableLayoutPanel2.Controls.Add(this.checkBox79, 7, 7);
            this.tableLayoutPanel2.Controls.Add(this.checkBox80, 7, 8);
            this.tableLayoutPanel2.Controls.Add(this.checkBox81, 7, 9);
            this.tableLayoutPanel2.Controls.Add(this.checkBox82, 7, 10);
            this.tableLayoutPanel2.Controls.Add(this.checkBox83, 7, 11);
            this.tableLayoutPanel2.Controls.Add(this.checkBox84, 7, 12);
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(5, 13);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 13;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.60241F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.39759F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(739, 364);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 340);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 12);
            this.label1.TabIndex = 36;
            this.label1.Text = "20:00 - 21:00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 26;
            this.label2.Text = "10:00 - 11:00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(88, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Sunday";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(181, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Monday";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(275, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Tuesday";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(368, 3);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Wednesday";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(472, 3);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Thursday";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(560, 3);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Friday";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(645, 3);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Saturday";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(5, 85);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(60, 12);
            this.label29.TabIndex = 25;
            this.label29.Text = "09:00 - 10:00";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 133);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 12);
            this.label30.TabIndex = 27;
            this.label30.Text = "11:00 - 12:00";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(6, 156);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(60, 12);
            this.label31.TabIndex = 28;
            this.label31.Text = "12:00 - 13:00";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(6, 179);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 12);
            this.label32.TabIndex = 29;
            this.label32.Text = "13:00 - 14:00";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(6, 202);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(60, 12);
            this.label33.TabIndex = 30;
            this.label33.Text = "14:00 - 15:00";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(6, 225);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(60, 12);
            this.label34.TabIndex = 31;
            this.label34.Text = "15:00 - 16:00";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(6, 248);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(60, 12);
            this.label35.TabIndex = 32;
            this.label35.Text = "16:00 - 17:00";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(6, 271);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(60, 12);
            this.label36.TabIndex = 33;
            this.label36.Text = "17:00 - 18:00";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(6, 294);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(60, 12);
            this.label37.TabIndex = 34;
            this.label37.Text = "18:00 - 19:00";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Times New Roman", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(6, 317);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(60, 12);
            this.label38.TabIndex = 35;
            this.label38.Text = "19:00 - 20:00";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(88, 88);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 37;
            this.checkBox1.Tag = "11";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(88, 112);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 38;
            this.checkBox2.Tag = "12";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(88, 159);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 38;
            this.checkBox3.Tag = "14";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(88, 136);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 38;
            this.checkBox4.Tag = "13";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(88, 182);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 38;
            this.checkBox5.Tag = "15";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(88, 205);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 38;
            this.checkBox6.Tag = "16";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(88, 228);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 38;
            this.checkBox7.Tag = "17";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(88, 251);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(15, 14);
            this.checkBox8.TabIndex = 38;
            this.checkBox8.Tag = "18";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(88, 274);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(15, 14);
            this.checkBox9.TabIndex = 38;
            this.checkBox9.Tag = "19";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(88, 297);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(15, 14);
            this.checkBox10.TabIndex = 38;
            this.checkBox10.Tag = "110";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(88, 320);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(15, 14);
            this.checkBox11.TabIndex = 38;
            this.checkBox11.Tag = "111";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(88, 343);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(15, 14);
            this.checkBox12.TabIndex = 38;
            this.checkBox12.Tag = "112";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(181, 88);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(15, 14);
            this.checkBox13.TabIndex = 37;
            this.checkBox13.Tag = "21";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(181, 112);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(15, 14);
            this.checkBox14.TabIndex = 37;
            this.checkBox14.Tag = "22";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(181, 159);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(15, 14);
            this.checkBox15.TabIndex = 37;
            this.checkBox15.Tag = "24";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(181, 136);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(15, 14);
            this.checkBox16.TabIndex = 37;
            this.checkBox16.Tag = "23";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(181, 182);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(15, 14);
            this.checkBox17.TabIndex = 37;
            this.checkBox17.Tag = "25";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(181, 205);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(15, 14);
            this.checkBox18.TabIndex = 37;
            this.checkBox18.Tag = "26";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(181, 228);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(15, 14);
            this.checkBox19.TabIndex = 37;
            this.checkBox19.Tag = "27";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(181, 251);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(15, 14);
            this.checkBox20.TabIndex = 37;
            this.checkBox20.Tag = "28";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(181, 274);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(15, 14);
            this.checkBox21.TabIndex = 37;
            this.checkBox21.Tag = "29";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(181, 297);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(15, 14);
            this.checkBox22.TabIndex = 37;
            this.checkBox22.Tag = "210";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(181, 320);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(15, 14);
            this.checkBox23.TabIndex = 37;
            this.checkBox23.Tag = "211";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(181, 343);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(15, 14);
            this.checkBox24.TabIndex = 37;
            this.checkBox24.Tag = "212";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(275, 88);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(15, 14);
            this.checkBox25.TabIndex = 37;
            this.checkBox25.Tag = "31";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(275, 112);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(15, 14);
            this.checkBox26.TabIndex = 37;
            this.checkBox26.Tag = "32";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Location = new System.Drawing.Point(275, 136);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(15, 14);
            this.checkBox27.TabIndex = 37;
            this.checkBox27.Tag = "33";
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Location = new System.Drawing.Point(275, 159);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(15, 14);
            this.checkBox28.TabIndex = 37;
            this.checkBox28.Tag = "34";
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Location = new System.Drawing.Point(275, 182);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(15, 14);
            this.checkBox29.TabIndex = 37;
            this.checkBox29.Tag = "35";
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Location = new System.Drawing.Point(275, 205);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(15, 14);
            this.checkBox30.TabIndex = 37;
            this.checkBox30.Tag = "36";
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Location = new System.Drawing.Point(275, 228);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(15, 14);
            this.checkBox31.TabIndex = 37;
            this.checkBox31.Tag = "37";
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Location = new System.Drawing.Point(275, 251);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(15, 14);
            this.checkBox32.TabIndex = 37;
            this.checkBox32.Tag = "38";
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Location = new System.Drawing.Point(275, 274);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(15, 14);
            this.checkBox33.TabIndex = 37;
            this.checkBox33.Tag = "39";
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Location = new System.Drawing.Point(275, 297);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(15, 14);
            this.checkBox34.TabIndex = 37;
            this.checkBox34.Tag = "310";
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.Location = new System.Drawing.Point(275, 320);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(15, 14);
            this.checkBox35.TabIndex = 37;
            this.checkBox35.Tag = "311";
            this.checkBox35.UseVisualStyleBackColor = true;
            // 
            // checkBox36
            // 
            this.checkBox36.AutoSize = true;
            this.checkBox36.Location = new System.Drawing.Point(275, 343);
            this.checkBox36.Name = "checkBox36";
            this.checkBox36.Size = new System.Drawing.Size(15, 14);
            this.checkBox36.TabIndex = 37;
            this.checkBox36.Tag = "312";
            this.checkBox36.UseVisualStyleBackColor = true;
            // 
            // checkBox37
            // 
            this.checkBox37.AutoSize = true;
            this.checkBox37.Location = new System.Drawing.Point(369, 88);
            this.checkBox37.Name = "checkBox37";
            this.checkBox37.Size = new System.Drawing.Size(15, 14);
            this.checkBox37.TabIndex = 37;
            this.checkBox37.Tag = "41";
            this.checkBox37.UseVisualStyleBackColor = true;
            // 
            // checkBox38
            // 
            this.checkBox38.AutoSize = true;
            this.checkBox38.Location = new System.Drawing.Point(369, 112);
            this.checkBox38.Name = "checkBox38";
            this.checkBox38.Size = new System.Drawing.Size(15, 14);
            this.checkBox38.TabIndex = 37;
            this.checkBox38.Tag = "42";
            this.checkBox38.UseVisualStyleBackColor = true;
            // 
            // checkBox39
            // 
            this.checkBox39.AutoSize = true;
            this.checkBox39.Location = new System.Drawing.Point(369, 136);
            this.checkBox39.Name = "checkBox39";
            this.checkBox39.Size = new System.Drawing.Size(15, 14);
            this.checkBox39.TabIndex = 37;
            this.checkBox39.Tag = "43";
            this.checkBox39.UseVisualStyleBackColor = true;
            // 
            // checkBox40
            // 
            this.checkBox40.AutoSize = true;
            this.checkBox40.Location = new System.Drawing.Point(369, 182);
            this.checkBox40.Name = "checkBox40";
            this.checkBox40.Size = new System.Drawing.Size(15, 14);
            this.checkBox40.TabIndex = 37;
            this.checkBox40.Tag = "45";
            this.checkBox40.UseVisualStyleBackColor = true;
            // 
            // checkBox41
            // 
            this.checkBox41.AutoSize = true;
            this.checkBox41.Location = new System.Drawing.Point(369, 159);
            this.checkBox41.Name = "checkBox41";
            this.checkBox41.Size = new System.Drawing.Size(15, 14);
            this.checkBox41.TabIndex = 37;
            this.checkBox41.Tag = "44";
            this.checkBox41.UseVisualStyleBackColor = true;
            // 
            // checkBox42
            // 
            this.checkBox42.AutoSize = true;
            this.checkBox42.Location = new System.Drawing.Point(369, 205);
            this.checkBox42.Name = "checkBox42";
            this.checkBox42.Size = new System.Drawing.Size(15, 14);
            this.checkBox42.TabIndex = 37;
            this.checkBox42.Tag = "46";
            this.checkBox42.UseVisualStyleBackColor = true;
            // 
            // checkBox43
            // 
            this.checkBox43.AutoSize = true;
            this.checkBox43.Location = new System.Drawing.Point(369, 228);
            this.checkBox43.Name = "checkBox43";
            this.checkBox43.Size = new System.Drawing.Size(15, 14);
            this.checkBox43.TabIndex = 37;
            this.checkBox43.Tag = "47";
            this.checkBox43.UseVisualStyleBackColor = true;
            // 
            // checkBox44
            // 
            this.checkBox44.AutoSize = true;
            this.checkBox44.Location = new System.Drawing.Point(369, 251);
            this.checkBox44.Name = "checkBox44";
            this.checkBox44.Size = new System.Drawing.Size(15, 14);
            this.checkBox44.TabIndex = 37;
            this.checkBox44.Tag = "48";
            this.checkBox44.UseVisualStyleBackColor = true;
            // 
            // checkBox45
            // 
            this.checkBox45.AutoSize = true;
            this.checkBox45.Location = new System.Drawing.Point(369, 274);
            this.checkBox45.Name = "checkBox45";
            this.checkBox45.Size = new System.Drawing.Size(15, 14);
            this.checkBox45.TabIndex = 37;
            this.checkBox45.Tag = "49";
            this.checkBox45.UseVisualStyleBackColor = true;
            // 
            // checkBox46
            // 
            this.checkBox46.AutoSize = true;
            this.checkBox46.Location = new System.Drawing.Point(369, 297);
            this.checkBox46.Name = "checkBox46";
            this.checkBox46.Size = new System.Drawing.Size(15, 14);
            this.checkBox46.TabIndex = 37;
            this.checkBox46.Tag = "410";
            this.checkBox46.UseVisualStyleBackColor = true;
            // 
            // checkBox47
            // 
            this.checkBox47.AutoSize = true;
            this.checkBox47.Location = new System.Drawing.Point(369, 320);
            this.checkBox47.Name = "checkBox47";
            this.checkBox47.Size = new System.Drawing.Size(15, 14);
            this.checkBox47.TabIndex = 37;
            this.checkBox47.Tag = "411";
            this.checkBox47.UseVisualStyleBackColor = true;
            // 
            // checkBox48
            // 
            this.checkBox48.AutoSize = true;
            this.checkBox48.Location = new System.Drawing.Point(369, 343);
            this.checkBox48.Name = "checkBox48";
            this.checkBox48.Size = new System.Drawing.Size(15, 14);
            this.checkBox48.TabIndex = 37;
            this.checkBox48.Tag = "412";
            this.checkBox48.UseVisualStyleBackColor = true;
            // 
            // checkBox49
            // 
            this.checkBox49.AutoSize = true;
            this.checkBox49.Location = new System.Drawing.Point(473, 88);
            this.checkBox49.Name = "checkBox49";
            this.checkBox49.Size = new System.Drawing.Size(15, 14);
            this.checkBox49.TabIndex = 37;
            this.checkBox49.Tag = "51";
            this.checkBox49.UseVisualStyleBackColor = true;
            // 
            // checkBox50
            // 
            this.checkBox50.AutoSize = true;
            this.checkBox50.Location = new System.Drawing.Point(473, 112);
            this.checkBox50.Name = "checkBox50";
            this.checkBox50.Size = new System.Drawing.Size(15, 14);
            this.checkBox50.TabIndex = 37;
            this.checkBox50.Tag = "52";
            this.checkBox50.UseVisualStyleBackColor = true;
            // 
            // checkBox51
            // 
            this.checkBox51.AutoSize = true;
            this.checkBox51.Location = new System.Drawing.Point(473, 136);
            this.checkBox51.Name = "checkBox51";
            this.checkBox51.Size = new System.Drawing.Size(15, 14);
            this.checkBox51.TabIndex = 37;
            this.checkBox51.Tag = "53";
            this.checkBox51.UseVisualStyleBackColor = true;
            // 
            // checkBox52
            // 
            this.checkBox52.AutoSize = true;
            this.checkBox52.Location = new System.Drawing.Point(473, 159);
            this.checkBox52.Name = "checkBox52";
            this.checkBox52.Size = new System.Drawing.Size(15, 14);
            this.checkBox52.TabIndex = 37;
            this.checkBox52.Tag = "54";
            this.checkBox52.UseVisualStyleBackColor = true;
            // 
            // checkBox53
            // 
            this.checkBox53.AutoSize = true;
            this.checkBox53.Location = new System.Drawing.Point(473, 182);
            this.checkBox53.Name = "checkBox53";
            this.checkBox53.Size = new System.Drawing.Size(15, 14);
            this.checkBox53.TabIndex = 37;
            this.checkBox53.Tag = "55";
            this.checkBox53.UseVisualStyleBackColor = true;
            // 
            // checkBox54
            // 
            this.checkBox54.AutoSize = true;
            this.checkBox54.Location = new System.Drawing.Point(473, 205);
            this.checkBox54.Name = "checkBox54";
            this.checkBox54.Size = new System.Drawing.Size(15, 14);
            this.checkBox54.TabIndex = 37;
            this.checkBox54.Tag = "56";
            this.checkBox54.UseVisualStyleBackColor = true;
            // 
            // checkBox55
            // 
            this.checkBox55.AutoSize = true;
            this.checkBox55.Location = new System.Drawing.Point(473, 228);
            this.checkBox55.Name = "checkBox55";
            this.checkBox55.Size = new System.Drawing.Size(15, 14);
            this.checkBox55.TabIndex = 37;
            this.checkBox55.Tag = "57";
            this.checkBox55.UseVisualStyleBackColor = true;
            // 
            // checkBox56
            // 
            this.checkBox56.AutoSize = true;
            this.checkBox56.Location = new System.Drawing.Point(473, 251);
            this.checkBox56.Name = "checkBox56";
            this.checkBox56.Size = new System.Drawing.Size(15, 14);
            this.checkBox56.TabIndex = 37;
            this.checkBox56.Tag = "58";
            this.checkBox56.UseVisualStyleBackColor = true;
            // 
            // checkBox57
            // 
            this.checkBox57.AutoSize = true;
            this.checkBox57.Location = new System.Drawing.Point(473, 274);
            this.checkBox57.Name = "checkBox57";
            this.checkBox57.Size = new System.Drawing.Size(15, 14);
            this.checkBox57.TabIndex = 37;
            this.checkBox57.Tag = "59";
            this.checkBox57.UseVisualStyleBackColor = true;
            // 
            // checkBox58
            // 
            this.checkBox58.AutoSize = true;
            this.checkBox58.Location = new System.Drawing.Point(473, 297);
            this.checkBox58.Name = "checkBox58";
            this.checkBox58.Size = new System.Drawing.Size(15, 14);
            this.checkBox58.TabIndex = 37;
            this.checkBox58.Tag = "510";
            this.checkBox58.UseVisualStyleBackColor = true;
            // 
            // checkBox59
            // 
            this.checkBox59.AutoSize = true;
            this.checkBox59.Location = new System.Drawing.Point(473, 320);
            this.checkBox59.Name = "checkBox59";
            this.checkBox59.Size = new System.Drawing.Size(15, 14);
            this.checkBox59.TabIndex = 37;
            this.checkBox59.Tag = "511";
            this.checkBox59.UseVisualStyleBackColor = true;
            // 
            // checkBox60
            // 
            this.checkBox60.AutoSize = true;
            this.checkBox60.Location = new System.Drawing.Point(473, 343);
            this.checkBox60.Name = "checkBox60";
            this.checkBox60.Size = new System.Drawing.Size(15, 14);
            this.checkBox60.TabIndex = 37;
            this.checkBox60.Tag = "512";
            this.checkBox60.UseVisualStyleBackColor = true;
            // 
            // checkBox61
            // 
            this.checkBox61.AutoSize = true;
            this.checkBox61.Location = new System.Drawing.Point(561, 88);
            this.checkBox61.Name = "checkBox61";
            this.checkBox61.Size = new System.Drawing.Size(15, 14);
            this.checkBox61.TabIndex = 37;
            this.checkBox61.Tag = "61";
            this.checkBox61.UseVisualStyleBackColor = true;
            // 
            // checkBox62
            // 
            this.checkBox62.AutoSize = true;
            this.checkBox62.Location = new System.Drawing.Point(561, 112);
            this.checkBox62.Name = "checkBox62";
            this.checkBox62.Size = new System.Drawing.Size(15, 14);
            this.checkBox62.TabIndex = 37;
            this.checkBox62.Tag = "62";
            this.checkBox62.UseVisualStyleBackColor = true;
            // 
            // checkBox63
            // 
            this.checkBox63.AutoSize = true;
            this.checkBox63.Location = new System.Drawing.Point(561, 136);
            this.checkBox63.Name = "checkBox63";
            this.checkBox63.Size = new System.Drawing.Size(15, 14);
            this.checkBox63.TabIndex = 37;
            this.checkBox63.Tag = "63";
            this.checkBox63.UseVisualStyleBackColor = true;
            // 
            // checkBox64
            // 
            this.checkBox64.AutoSize = true;
            this.checkBox64.Location = new System.Drawing.Point(561, 159);
            this.checkBox64.Name = "checkBox64";
            this.checkBox64.Size = new System.Drawing.Size(15, 14);
            this.checkBox64.TabIndex = 37;
            this.checkBox64.Tag = "64";
            this.checkBox64.UseVisualStyleBackColor = true;
            // 
            // checkBox65
            // 
            this.checkBox65.AutoSize = true;
            this.checkBox65.Location = new System.Drawing.Point(561, 182);
            this.checkBox65.Name = "checkBox65";
            this.checkBox65.Size = new System.Drawing.Size(15, 14);
            this.checkBox65.TabIndex = 37;
            this.checkBox65.Tag = "65";
            this.checkBox65.UseVisualStyleBackColor = true;
            // 
            // checkBox66
            // 
            this.checkBox66.AutoSize = true;
            this.checkBox66.Location = new System.Drawing.Point(561, 205);
            this.checkBox66.Name = "checkBox66";
            this.checkBox66.Size = new System.Drawing.Size(15, 14);
            this.checkBox66.TabIndex = 37;
            this.checkBox66.Tag = "66";
            this.checkBox66.UseVisualStyleBackColor = true;
            // 
            // checkBox67
            // 
            this.checkBox67.AutoSize = true;
            this.checkBox67.Location = new System.Drawing.Point(561, 228);
            this.checkBox67.Name = "checkBox67";
            this.checkBox67.Size = new System.Drawing.Size(15, 14);
            this.checkBox67.TabIndex = 37;
            this.checkBox67.Tag = "67";
            this.checkBox67.UseVisualStyleBackColor = true;
            // 
            // checkBox68
            // 
            this.checkBox68.AutoSize = true;
            this.checkBox68.Location = new System.Drawing.Point(561, 251);
            this.checkBox68.Name = "checkBox68";
            this.checkBox68.Size = new System.Drawing.Size(15, 14);
            this.checkBox68.TabIndex = 37;
            this.checkBox68.Tag = "68";
            this.checkBox68.UseVisualStyleBackColor = true;
            // 
            // checkBox69
            // 
            this.checkBox69.AutoSize = true;
            this.checkBox69.Location = new System.Drawing.Point(561, 274);
            this.checkBox69.Name = "checkBox69";
            this.checkBox69.Size = new System.Drawing.Size(15, 14);
            this.checkBox69.TabIndex = 37;
            this.checkBox69.Tag = "69";
            this.checkBox69.UseVisualStyleBackColor = true;
            // 
            // checkBox70
            // 
            this.checkBox70.AutoSize = true;
            this.checkBox70.Location = new System.Drawing.Point(561, 297);
            this.checkBox70.Name = "checkBox70";
            this.checkBox70.Size = new System.Drawing.Size(15, 14);
            this.checkBox70.TabIndex = 37;
            this.checkBox70.Tag = "610";
            this.checkBox70.UseVisualStyleBackColor = true;
            // 
            // checkBox71
            // 
            this.checkBox71.AutoSize = true;
            this.checkBox71.Location = new System.Drawing.Point(561, 320);
            this.checkBox71.Name = "checkBox71";
            this.checkBox71.Size = new System.Drawing.Size(15, 14);
            this.checkBox71.TabIndex = 37;
            this.checkBox71.Tag = "611";
            this.checkBox71.UseVisualStyleBackColor = true;
            // 
            // checkBox72
            // 
            this.checkBox72.AutoSize = true;
            this.checkBox72.Location = new System.Drawing.Point(561, 343);
            this.checkBox72.Name = "checkBox72";
            this.checkBox72.Size = new System.Drawing.Size(15, 14);
            this.checkBox72.TabIndex = 37;
            this.checkBox72.Tag = "612";
            this.checkBox72.UseVisualStyleBackColor = true;
            // 
            // checkBox73
            // 
            this.checkBox73.AutoSize = true;
            this.checkBox73.Location = new System.Drawing.Point(646, 112);
            this.checkBox73.Name = "checkBox73";
            this.checkBox73.Size = new System.Drawing.Size(15, 14);
            this.checkBox73.TabIndex = 37;
            this.checkBox73.Tag = "72";
            this.checkBox73.UseVisualStyleBackColor = true;
            // 
            // checkBox74
            // 
            this.checkBox74.AutoSize = true;
            this.checkBox74.Location = new System.Drawing.Point(646, 88);
            this.checkBox74.Name = "checkBox74";
            this.checkBox74.Size = new System.Drawing.Size(15, 14);
            this.checkBox74.TabIndex = 37;
            this.checkBox74.Tag = "71";
            this.checkBox74.UseVisualStyleBackColor = true;
            // 
            // checkBox75
            // 
            this.checkBox75.AutoSize = true;
            this.checkBox75.Location = new System.Drawing.Point(646, 136);
            this.checkBox75.Name = "checkBox75";
            this.checkBox75.Size = new System.Drawing.Size(15, 14);
            this.checkBox75.TabIndex = 37;
            this.checkBox75.Tag = "73";
            this.checkBox75.UseVisualStyleBackColor = true;
            // 
            // checkBox76
            // 
            this.checkBox76.AutoSize = true;
            this.checkBox76.Location = new System.Drawing.Point(646, 159);
            this.checkBox76.Name = "checkBox76";
            this.checkBox76.Size = new System.Drawing.Size(15, 14);
            this.checkBox76.TabIndex = 37;
            this.checkBox76.Tag = "74";
            this.checkBox76.UseVisualStyleBackColor = true;
            // 
            // checkBox77
            // 
            this.checkBox77.AutoSize = true;
            this.checkBox77.Location = new System.Drawing.Point(646, 182);
            this.checkBox77.Name = "checkBox77";
            this.checkBox77.Size = new System.Drawing.Size(15, 14);
            this.checkBox77.TabIndex = 37;
            this.checkBox77.Tag = "75";
            this.checkBox77.UseVisualStyleBackColor = true;
            // 
            // checkBox78
            // 
            this.checkBox78.AutoSize = true;
            this.checkBox78.Location = new System.Drawing.Point(646, 205);
            this.checkBox78.Name = "checkBox78";
            this.checkBox78.Size = new System.Drawing.Size(15, 14);
            this.checkBox78.TabIndex = 37;
            this.checkBox78.Tag = "76";
            this.checkBox78.UseVisualStyleBackColor = true;
            // 
            // checkBox79
            // 
            this.checkBox79.AutoSize = true;
            this.checkBox79.Location = new System.Drawing.Point(646, 228);
            this.checkBox79.Name = "checkBox79";
            this.checkBox79.Size = new System.Drawing.Size(15, 14);
            this.checkBox79.TabIndex = 37;
            this.checkBox79.Tag = "77";
            this.checkBox79.UseVisualStyleBackColor = true;
            // 
            // checkBox80
            // 
            this.checkBox80.AutoSize = true;
            this.checkBox80.Location = new System.Drawing.Point(646, 251);
            this.checkBox80.Name = "checkBox80";
            this.checkBox80.Size = new System.Drawing.Size(15, 14);
            this.checkBox80.TabIndex = 37;
            this.checkBox80.Tag = "78";
            this.checkBox80.UseVisualStyleBackColor = true;
            // 
            // checkBox81
            // 
            this.checkBox81.AutoSize = true;
            this.checkBox81.Location = new System.Drawing.Point(646, 274);
            this.checkBox81.Name = "checkBox81";
            this.checkBox81.Size = new System.Drawing.Size(15, 14);
            this.checkBox81.TabIndex = 37;
            this.checkBox81.Tag = "79";
            this.checkBox81.UseVisualStyleBackColor = true;
            // 
            // checkBox82
            // 
            this.checkBox82.AutoSize = true;
            this.checkBox82.Location = new System.Drawing.Point(646, 297);
            this.checkBox82.Name = "checkBox82";
            this.checkBox82.Size = new System.Drawing.Size(15, 14);
            this.checkBox82.TabIndex = 37;
            this.checkBox82.Tag = "710";
            this.checkBox82.UseVisualStyleBackColor = true;
            // 
            // checkBox83
            // 
            this.checkBox83.AutoSize = true;
            this.checkBox83.Location = new System.Drawing.Point(646, 320);
            this.checkBox83.Name = "checkBox83";
            this.checkBox83.Size = new System.Drawing.Size(15, 14);
            this.checkBox83.TabIndex = 37;
            this.checkBox83.Tag = "711";
            this.checkBox83.UseVisualStyleBackColor = true;
            // 
            // checkBox84
            // 
            this.checkBox84.AutoSize = true;
            this.checkBox84.Location = new System.Drawing.Point(646, 343);
            this.checkBox84.Name = "checkBox84";
            this.checkBox84.Size = new System.Drawing.Size(15, 14);
            this.checkBox84.TabIndex = 37;
            this.checkBox84.Tag = "712";
            this.checkBox84.UseVisualStyleBackColor = true;
            // 
            // AvailabilityButton
            // 
            this.AvailabilityButton.Location = new System.Drawing.Point(336, 390);
            this.AvailabilityButton.Margin = new System.Windows.Forms.Padding(2);
            this.AvailabilityButton.Name = "AvailabilityButton";
            this.AvailabilityButton.Size = new System.Drawing.Size(72, 19);
            this.AvailabilityButton.TabIndex = 1;
            this.AvailabilityButton.Text = "Submit";
            this.AvailabilityButton.UseVisualStyleBackColor = true;
            this.AvailabilityButton.Click += new System.EventHandler(this.AvailabilityButton_Click);
            // 
            // UserTabControl
            // 
            this.UserTabControl.Controls.Add(this.AvailabilityTab);
            this.UserTabControl.Controls.Add(this.ViewScheduleTab);
            this.UserTabControl.Font = new System.Drawing.Font("Times New Roman", 8.25F);
            this.UserTabControl.Location = new System.Drawing.Point(9, 25);
            this.UserTabControl.Margin = new System.Windows.Forms.Padding(2);
            this.UserTabControl.Name = "UserTabControl";
            this.UserTabControl.SelectedIndex = 0;
            this.UserTabControl.Size = new System.Drawing.Size(757, 441);
            this.UserTabControl.TabIndex = 1;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Location = new System.Drawing.Point(88, 85);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(23, 13);
            this.lbl11.TabIndex = 37;
            this.lbl11.Text = "NA";
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Location = new System.Drawing.Point(88, 110);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(23, 13);
            this.lbl12.TabIndex = 37;
            this.lbl12.Text = "NA";
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Location = new System.Drawing.Point(88, 135);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(23, 13);
            this.lbl13.TabIndex = 37;
            this.lbl13.Text = "NA";
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Location = new System.Drawing.Point(88, 158);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(23, 13);
            this.lbl14.TabIndex = 37;
            this.lbl14.Text = "NA";
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Location = new System.Drawing.Point(88, 181);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(23, 13);
            this.lbl15.TabIndex = 37;
            this.lbl15.Text = "NA";
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Location = new System.Drawing.Point(88, 204);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(23, 13);
            this.lbl16.TabIndex = 37;
            this.lbl16.Text = "NA";
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Location = new System.Drawing.Point(88, 227);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(23, 13);
            this.lbl17.TabIndex = 37;
            this.lbl17.Text = "NA";
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Location = new System.Drawing.Point(88, 250);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(23, 13);
            this.lbl18.TabIndex = 37;
            this.lbl18.Text = "NA";
            // 
            // lbl19
            // 
            this.lbl19.AutoSize = true;
            this.lbl19.Location = new System.Drawing.Point(88, 273);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(23, 13);
            this.lbl19.TabIndex = 37;
            this.lbl19.Text = "NA";
            // 
            // lbl110
            // 
            this.lbl110.AutoSize = true;
            this.lbl110.Location = new System.Drawing.Point(88, 296);
            this.lbl110.Name = "lbl110";
            this.lbl110.Size = new System.Drawing.Size(23, 13);
            this.lbl110.TabIndex = 37;
            this.lbl110.Text = "NA";
            // 
            // lbl111
            // 
            this.lbl111.AutoSize = true;
            this.lbl111.Location = new System.Drawing.Point(88, 319);
            this.lbl111.Name = "lbl111";
            this.lbl111.Size = new System.Drawing.Size(23, 13);
            this.lbl111.TabIndex = 37;
            this.lbl111.Text = "NA";
            // 
            // lbl112
            // 
            this.lbl112.AutoSize = true;
            this.lbl112.Location = new System.Drawing.Point(88, 342);
            this.lbl112.Name = "lbl112";
            this.lbl112.Size = new System.Drawing.Size(23, 13);
            this.lbl112.TabIndex = 37;
            this.lbl112.Text = "NA";
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.Location = new System.Drawing.Point(181, 85);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(23, 13);
            this.lbl21.TabIndex = 37;
            this.lbl21.Text = "NA";
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Location = new System.Drawing.Point(181, 110);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(23, 13);
            this.lbl22.TabIndex = 37;
            this.lbl22.Text = "NA";
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.Location = new System.Drawing.Point(181, 135);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(23, 13);
            this.lbl23.TabIndex = 37;
            this.lbl23.Text = "NA";
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.Location = new System.Drawing.Point(181, 158);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(23, 13);
            this.lbl24.TabIndex = 37;
            this.lbl24.Text = "NA";
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.Location = new System.Drawing.Point(181, 181);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(23, 13);
            this.lbl25.TabIndex = 37;
            this.lbl25.Text = "NA";
            // 
            // lbl26
            // 
            this.lbl26.AutoSize = true;
            this.lbl26.Location = new System.Drawing.Point(181, 204);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(23, 13);
            this.lbl26.TabIndex = 37;
            this.lbl26.Text = "NA";
            // 
            // lbl27
            // 
            this.lbl27.AutoSize = true;
            this.lbl27.Location = new System.Drawing.Point(181, 227);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(23, 13);
            this.lbl27.TabIndex = 37;
            this.lbl27.Text = "NA";
            // 
            // lbl28
            // 
            this.lbl28.AutoSize = true;
            this.lbl28.Location = new System.Drawing.Point(181, 250);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(23, 13);
            this.lbl28.TabIndex = 37;
            this.lbl28.Text = "NA";
            // 
            // lbl29
            // 
            this.lbl29.AutoSize = true;
            this.lbl29.Location = new System.Drawing.Point(181, 273);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(23, 13);
            this.lbl29.TabIndex = 37;
            this.lbl29.Text = "NA";
            // 
            // lbl210
            // 
            this.lbl210.AutoSize = true;
            this.lbl210.Location = new System.Drawing.Point(181, 296);
            this.lbl210.Name = "lbl210";
            this.lbl210.Size = new System.Drawing.Size(23, 13);
            this.lbl210.TabIndex = 37;
            this.lbl210.Text = "NA";
            // 
            // lbl211
            // 
            this.lbl211.AutoSize = true;
            this.lbl211.Location = new System.Drawing.Point(181, 319);
            this.lbl211.Name = "lbl211";
            this.lbl211.Size = new System.Drawing.Size(23, 13);
            this.lbl211.TabIndex = 37;
            this.lbl211.Text = "NA";
            // 
            // lbl212
            // 
            this.lbl212.AutoSize = true;
            this.lbl212.Location = new System.Drawing.Point(181, 342);
            this.lbl212.Name = "lbl212";
            this.lbl212.Size = new System.Drawing.Size(23, 13);
            this.lbl212.TabIndex = 37;
            this.lbl212.Text = "NA";
            // 
            // lbl31
            // 
            this.lbl31.AutoSize = true;
            this.lbl31.Location = new System.Drawing.Point(275, 85);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(23, 13);
            this.lbl31.TabIndex = 37;
            this.lbl31.Text = "NA";
            // 
            // lbl32
            // 
            this.lbl32.AutoSize = true;
            this.lbl32.Location = new System.Drawing.Point(275, 110);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(23, 13);
            this.lbl32.TabIndex = 37;
            this.lbl32.Text = "NA";
            // 
            // lbl33
            // 
            this.lbl33.AutoSize = true;
            this.lbl33.Location = new System.Drawing.Point(275, 135);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(23, 13);
            this.lbl33.TabIndex = 37;
            this.lbl33.Text = "NA";
            // 
            // lbl34
            // 
            this.lbl34.AutoSize = true;
            this.lbl34.Location = new System.Drawing.Point(275, 158);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(23, 13);
            this.lbl34.TabIndex = 37;
            this.lbl34.Text = "NA";
            // 
            // lbl35
            // 
            this.lbl35.AutoSize = true;
            this.lbl35.Location = new System.Drawing.Point(275, 181);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(23, 13);
            this.lbl35.TabIndex = 37;
            this.lbl35.Text = "NA";
            // 
            // lbl36
            // 
            this.lbl36.AutoSize = true;
            this.lbl36.Location = new System.Drawing.Point(275, 204);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(23, 13);
            this.lbl36.TabIndex = 37;
            this.lbl36.Text = "NA";
            // 
            // lbl37
            // 
            this.lbl37.AutoSize = true;
            this.lbl37.Location = new System.Drawing.Point(275, 227);
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(23, 13);
            this.lbl37.TabIndex = 37;
            this.lbl37.Text = "NA";
            // 
            // lbl38
            // 
            this.lbl38.AutoSize = true;
            this.lbl38.Location = new System.Drawing.Point(275, 250);
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(23, 13);
            this.lbl38.TabIndex = 37;
            this.lbl38.Text = "NA";
            // 
            // lbl39
            // 
            this.lbl39.AutoSize = true;
            this.lbl39.Location = new System.Drawing.Point(275, 273);
            this.lbl39.Name = "lbl39";
            this.lbl39.Size = new System.Drawing.Size(23, 13);
            this.lbl39.TabIndex = 37;
            this.lbl39.Text = "NA";
            // 
            // lbl310
            // 
            this.lbl310.AutoSize = true;
            this.lbl310.Location = new System.Drawing.Point(275, 296);
            this.lbl310.Name = "lbl310";
            this.lbl310.Size = new System.Drawing.Size(23, 13);
            this.lbl310.TabIndex = 37;
            this.lbl310.Text = "NA";
            // 
            // lbl311
            // 
            this.lbl311.AutoSize = true;
            this.lbl311.Location = new System.Drawing.Point(275, 319);
            this.lbl311.Name = "lbl311";
            this.lbl311.Size = new System.Drawing.Size(23, 13);
            this.lbl311.TabIndex = 37;
            this.lbl311.Text = "NA";
            // 
            // lbl312
            // 
            this.lbl312.AutoSize = true;
            this.lbl312.Location = new System.Drawing.Point(275, 342);
            this.lbl312.Name = "lbl312";
            this.lbl312.Size = new System.Drawing.Size(23, 13);
            this.lbl312.TabIndex = 37;
            this.lbl312.Text = "NA";
            // 
            // lbl41
            // 
            this.lbl41.AutoSize = true;
            this.lbl41.Location = new System.Drawing.Point(369, 85);
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(23, 13);
            this.lbl41.TabIndex = 37;
            this.lbl41.Text = "NA";
            // 
            // lbl42
            // 
            this.lbl42.AutoSize = true;
            this.lbl42.Location = new System.Drawing.Point(369, 110);
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(23, 13);
            this.lbl42.TabIndex = 37;
            this.lbl42.Text = "NA";
            // 
            // lbl43
            // 
            this.lbl43.AutoSize = true;
            this.lbl43.Location = new System.Drawing.Point(369, 135);
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(23, 13);
            this.lbl43.TabIndex = 37;
            this.lbl43.Text = "NA";
            // 
            // lbl44
            // 
            this.lbl44.AutoSize = true;
            this.lbl44.Location = new System.Drawing.Point(369, 158);
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(23, 13);
            this.lbl44.TabIndex = 37;
            this.lbl44.Text = "NA";
            // 
            // lbl45
            // 
            this.lbl45.AutoSize = true;
            this.lbl45.Location = new System.Drawing.Point(369, 181);
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(23, 13);
            this.lbl45.TabIndex = 37;
            this.lbl45.Text = "NA";
            // 
            // lbl46
            // 
            this.lbl46.AutoSize = true;
            this.lbl46.Location = new System.Drawing.Point(369, 204);
            this.lbl46.Name = "lbl46";
            this.lbl46.Size = new System.Drawing.Size(23, 13);
            this.lbl46.TabIndex = 37;
            this.lbl46.Text = "NA";
            // 
            // lbl47
            // 
            this.lbl47.AutoSize = true;
            this.lbl47.Location = new System.Drawing.Point(369, 227);
            this.lbl47.Name = "lbl47";
            this.lbl47.Size = new System.Drawing.Size(23, 13);
            this.lbl47.TabIndex = 37;
            this.lbl47.Text = "NA";
            // 
            // lbl48
            // 
            this.lbl48.AutoSize = true;
            this.lbl48.Location = new System.Drawing.Point(369, 250);
            this.lbl48.Name = "lbl48";
            this.lbl48.Size = new System.Drawing.Size(23, 13);
            this.lbl48.TabIndex = 37;
            this.lbl48.Text = "NA";
            // 
            // lbl49
            // 
            this.lbl49.AutoSize = true;
            this.lbl49.Location = new System.Drawing.Point(369, 273);
            this.lbl49.Name = "lbl49";
            this.lbl49.Size = new System.Drawing.Size(23, 13);
            this.lbl49.TabIndex = 37;
            this.lbl49.Text = "NA";
            // 
            // lbl410
            // 
            this.lbl410.AutoSize = true;
            this.lbl410.Location = new System.Drawing.Point(369, 296);
            this.lbl410.Name = "lbl410";
            this.lbl410.Size = new System.Drawing.Size(23, 13);
            this.lbl410.TabIndex = 37;
            this.lbl410.Text = "NA";
            // 
            // lbl411
            // 
            this.lbl411.AutoSize = true;
            this.lbl411.Location = new System.Drawing.Point(369, 319);
            this.lbl411.Name = "lbl411";
            this.lbl411.Size = new System.Drawing.Size(23, 13);
            this.lbl411.TabIndex = 37;
            this.lbl411.Text = "NA";
            // 
            // lbl412
            // 
            this.lbl412.AutoSize = true;
            this.lbl412.Location = new System.Drawing.Point(369, 342);
            this.lbl412.Name = "lbl412";
            this.lbl412.Size = new System.Drawing.Size(23, 13);
            this.lbl412.TabIndex = 37;
            this.lbl412.Text = "NA";
            // 
            // lbl51
            // 
            this.lbl51.AutoSize = true;
            this.lbl51.Location = new System.Drawing.Point(473, 85);
            this.lbl51.Name = "lbl51";
            this.lbl51.Size = new System.Drawing.Size(23, 13);
            this.lbl51.TabIndex = 37;
            this.lbl51.Text = "NA";
            // 
            // lbl52
            // 
            this.lbl52.AutoSize = true;
            this.lbl52.Location = new System.Drawing.Point(473, 110);
            this.lbl52.Name = "lbl52";
            this.lbl52.Size = new System.Drawing.Size(23, 13);
            this.lbl52.TabIndex = 37;
            this.lbl52.Text = "NA";
            // 
            // lbl53
            // 
            this.lbl53.AutoSize = true;
            this.lbl53.Location = new System.Drawing.Point(473, 135);
            this.lbl53.Name = "lbl53";
            this.lbl53.Size = new System.Drawing.Size(23, 13);
            this.lbl53.TabIndex = 37;
            this.lbl53.Text = "NA";
            // 
            // lbl54
            // 
            this.lbl54.AutoSize = true;
            this.lbl54.Location = new System.Drawing.Point(473, 158);
            this.lbl54.Name = "lbl54";
            this.lbl54.Size = new System.Drawing.Size(23, 13);
            this.lbl54.TabIndex = 37;
            this.lbl54.Text = "NA";
            // 
            // lbl55
            // 
            this.lbl55.AutoSize = true;
            this.lbl55.Location = new System.Drawing.Point(473, 181);
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(23, 13);
            this.lbl55.TabIndex = 37;
            this.lbl55.Text = "NA";
            // 
            // lbl56
            // 
            this.lbl56.AutoSize = true;
            this.lbl56.Location = new System.Drawing.Point(473, 204);
            this.lbl56.Name = "lbl56";
            this.lbl56.Size = new System.Drawing.Size(23, 13);
            this.lbl56.TabIndex = 37;
            this.lbl56.Text = "NA";
            // 
            // lbl57
            // 
            this.lbl57.AutoSize = true;
            this.lbl57.Location = new System.Drawing.Point(473, 227);
            this.lbl57.Name = "lbl57";
            this.lbl57.Size = new System.Drawing.Size(23, 13);
            this.lbl57.TabIndex = 37;
            this.lbl57.Text = "NA";
            // 
            // lbl58
            // 
            this.lbl58.AutoSize = true;
            this.lbl58.Location = new System.Drawing.Point(473, 250);
            this.lbl58.Name = "lbl58";
            this.lbl58.Size = new System.Drawing.Size(23, 13);
            this.lbl58.TabIndex = 37;
            this.lbl58.Text = "NA";
            // 
            // lbl59
            // 
            this.lbl59.AutoSize = true;
            this.lbl59.Location = new System.Drawing.Point(473, 273);
            this.lbl59.Name = "lbl59";
            this.lbl59.Size = new System.Drawing.Size(23, 13);
            this.lbl59.TabIndex = 37;
            this.lbl59.Text = "NA";
            // 
            // lbl510
            // 
            this.lbl510.AutoSize = true;
            this.lbl510.Location = new System.Drawing.Point(473, 296);
            this.lbl510.Name = "lbl510";
            this.lbl510.Size = new System.Drawing.Size(23, 13);
            this.lbl510.TabIndex = 37;
            this.lbl510.Text = "NA";
            // 
            // lbl511
            // 
            this.lbl511.AutoSize = true;
            this.lbl511.Location = new System.Drawing.Point(473, 319);
            this.lbl511.Name = "lbl511";
            this.lbl511.Size = new System.Drawing.Size(23, 13);
            this.lbl511.TabIndex = 37;
            this.lbl511.Text = "NA";
            // 
            // lbl62
            // 
            this.lbl62.AutoSize = true;
            this.lbl62.Location = new System.Drawing.Point(561, 110);
            this.lbl62.Name = "lbl62";
            this.lbl62.Size = new System.Drawing.Size(23, 13);
            this.lbl62.TabIndex = 37;
            this.lbl62.Text = "NA";
            // 
            // lbl61
            // 
            this.lbl61.AutoSize = true;
            this.lbl61.Location = new System.Drawing.Point(561, 85);
            this.lbl61.Name = "lbl61";
            this.lbl61.Size = new System.Drawing.Size(23, 13);
            this.lbl61.TabIndex = 37;
            this.lbl61.Text = "NA";
            // 
            // lbl63
            // 
            this.lbl63.AutoSize = true;
            this.lbl63.Location = new System.Drawing.Point(561, 135);
            this.lbl63.Name = "lbl63";
            this.lbl63.Size = new System.Drawing.Size(23, 13);
            this.lbl63.TabIndex = 37;
            this.lbl63.Text = "NA";
            // 
            // lbl64
            // 
            this.lbl64.AutoSize = true;
            this.lbl64.Location = new System.Drawing.Point(561, 158);
            this.lbl64.Name = "lbl64";
            this.lbl64.Size = new System.Drawing.Size(23, 13);
            this.lbl64.TabIndex = 37;
            this.lbl64.Text = "NA";
            // 
            // lbl65
            // 
            this.lbl65.AutoSize = true;
            this.lbl65.Location = new System.Drawing.Point(561, 181);
            this.lbl65.Name = "lbl65";
            this.lbl65.Size = new System.Drawing.Size(23, 13);
            this.lbl65.TabIndex = 37;
            this.lbl65.Text = "NA";
            // 
            // lbl66
            // 
            this.lbl66.AutoSize = true;
            this.lbl66.Location = new System.Drawing.Point(561, 204);
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(23, 13);
            this.lbl66.TabIndex = 37;
            this.lbl66.Text = "NA";
            // 
            // lbl512
            // 
            this.lbl512.AutoSize = true;
            this.lbl512.Location = new System.Drawing.Point(473, 342);
            this.lbl512.Name = "lbl512";
            this.lbl512.Size = new System.Drawing.Size(23, 13);
            this.lbl512.TabIndex = 37;
            this.lbl512.Text = "NA";
            // 
            // lbl67
            // 
            this.lbl67.AutoSize = true;
            this.lbl67.Location = new System.Drawing.Point(561, 227);
            this.lbl67.Name = "lbl67";
            this.lbl67.Size = new System.Drawing.Size(23, 13);
            this.lbl67.TabIndex = 37;
            this.lbl67.Text = "NA";
            // 
            // lbl68
            // 
            this.lbl68.AutoSize = true;
            this.lbl68.Location = new System.Drawing.Point(561, 250);
            this.lbl68.Name = "lbl68";
            this.lbl68.Size = new System.Drawing.Size(23, 13);
            this.lbl68.TabIndex = 37;
            this.lbl68.Text = "NA";
            // 
            // lbl69
            // 
            this.lbl69.AutoSize = true;
            this.lbl69.Location = new System.Drawing.Point(561, 273);
            this.lbl69.Name = "lbl69";
            this.lbl69.Size = new System.Drawing.Size(23, 13);
            this.lbl69.TabIndex = 37;
            this.lbl69.Text = "NA";
            // 
            // lbl610
            // 
            this.lbl610.AutoSize = true;
            this.lbl610.Location = new System.Drawing.Point(561, 296);
            this.lbl610.Name = "lbl610";
            this.lbl610.Size = new System.Drawing.Size(23, 13);
            this.lbl610.TabIndex = 37;
            this.lbl610.Text = "NA";
            // 
            // lbl611
            // 
            this.lbl611.AutoSize = true;
            this.lbl611.Location = new System.Drawing.Point(561, 319);
            this.lbl611.Name = "lbl611";
            this.lbl611.Size = new System.Drawing.Size(23, 13);
            this.lbl611.TabIndex = 37;
            this.lbl611.Text = "NA";
            // 
            // lbl612
            // 
            this.lbl612.AutoSize = true;
            this.lbl612.Location = new System.Drawing.Point(561, 342);
            this.lbl612.Name = "lbl612";
            this.lbl612.Size = new System.Drawing.Size(23, 13);
            this.lbl612.TabIndex = 37;
            this.lbl612.Text = "NA";
            // 
            // lbl71
            // 
            this.lbl71.AutoSize = true;
            this.lbl71.Location = new System.Drawing.Point(646, 85);
            this.lbl71.Name = "lbl71";
            this.lbl71.Size = new System.Drawing.Size(23, 13);
            this.lbl71.TabIndex = 37;
            this.lbl71.Text = "NA";
            // 
            // lbl72
            // 
            this.lbl72.AutoSize = true;
            this.lbl72.Location = new System.Drawing.Point(646, 110);
            this.lbl72.Name = "lbl72";
            this.lbl72.Size = new System.Drawing.Size(23, 13);
            this.lbl72.TabIndex = 37;
            this.lbl72.Text = "NA";
            // 
            // lbl73
            // 
            this.lbl73.AutoSize = true;
            this.lbl73.Location = new System.Drawing.Point(646, 135);
            this.lbl73.Name = "lbl73";
            this.lbl73.Size = new System.Drawing.Size(23, 13);
            this.lbl73.TabIndex = 37;
            this.lbl73.Text = "NA";
            // 
            // lbl74
            // 
            this.lbl74.AutoSize = true;
            this.lbl74.Location = new System.Drawing.Point(646, 158);
            this.lbl74.Name = "lbl74";
            this.lbl74.Size = new System.Drawing.Size(23, 13);
            this.lbl74.TabIndex = 37;
            this.lbl74.Text = "NA";
            // 
            // lbl75
            // 
            this.lbl75.AutoSize = true;
            this.lbl75.Location = new System.Drawing.Point(646, 181);
            this.lbl75.Name = "lbl75";
            this.lbl75.Size = new System.Drawing.Size(23, 13);
            this.lbl75.TabIndex = 37;
            this.lbl75.Text = "NA";
            // 
            // lbl76
            // 
            this.lbl76.AutoSize = true;
            this.lbl76.Location = new System.Drawing.Point(646, 204);
            this.lbl76.Name = "lbl76";
            this.lbl76.Size = new System.Drawing.Size(23, 13);
            this.lbl76.TabIndex = 37;
            this.lbl76.Text = "NA";
            // 
            // lbl77
            // 
            this.lbl77.AutoSize = true;
            this.lbl77.Location = new System.Drawing.Point(646, 227);
            this.lbl77.Name = "lbl77";
            this.lbl77.Size = new System.Drawing.Size(23, 13);
            this.lbl77.TabIndex = 37;
            this.lbl77.Text = "NA";
            // 
            // lbl78
            // 
            this.lbl78.AutoSize = true;
            this.lbl78.Location = new System.Drawing.Point(646, 250);
            this.lbl78.Name = "lbl78";
            this.lbl78.Size = new System.Drawing.Size(23, 13);
            this.lbl78.TabIndex = 37;
            this.lbl78.Text = "NA";
            // 
            // lbl79
            // 
            this.lbl79.AutoSize = true;
            this.lbl79.Location = new System.Drawing.Point(646, 273);
            this.lbl79.Name = "lbl79";
            this.lbl79.Size = new System.Drawing.Size(23, 13);
            this.lbl79.TabIndex = 37;
            this.lbl79.Text = "NA";
            // 
            // lbl710
            // 
            this.lbl710.AutoSize = true;
            this.lbl710.Location = new System.Drawing.Point(646, 296);
            this.lbl710.Name = "lbl710";
            this.lbl710.Size = new System.Drawing.Size(23, 13);
            this.lbl710.TabIndex = 37;
            this.lbl710.Text = "NA";
            // 
            // lbl711
            // 
            this.lbl711.AutoSize = true;
            this.lbl711.Location = new System.Drawing.Point(646, 319);
            this.lbl711.Name = "lbl711";
            this.lbl711.Size = new System.Drawing.Size(23, 13);
            this.lbl711.TabIndex = 37;
            this.lbl711.Text = "NA";
            // 
            // lbl712
            // 
            this.lbl712.AutoSize = true;
            this.lbl712.Location = new System.Drawing.Point(646, 342);
            this.lbl712.Name = "lbl712";
            this.lbl712.Size = new System.Drawing.Size(23, 13);
            this.lbl712.TabIndex = 37;
            this.lbl712.Text = "NA";
            // 
            // UserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 469);
            this.Controls.Add(this.UserTabControl);
            this.Controls.Add(this.UserMenuStrip);
            this.MainMenuStrip = this.UserMenuStrip;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UserForm";
            this.Text = "User Form";
            this.UserMenuStrip.ResumeLayout(false);
            this.UserMenuStrip.PerformLayout();
            this.ViewScheduleTab.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.AvailabilityTab.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.UserTabControl.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem FileMenuStripItem;
        private System.Windows.Forms.ToolStripMenuItem ExitMenuItem;
        private System.Windows.Forms.MenuStrip UserMenuStrip;
        private System.Windows.Forms.TabPage ViewScheduleTab;
        private System.Windows.Forms.TabPage AvailabilityTab;
        private System.Windows.Forms.Button AvailabilityButton;
        private System.Windows.Forms.TabControl UserTabControl;
        private System.Windows.Forms.ToolStripMenuItem askOffToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.CheckBox checkBox37;
        private System.Windows.Forms.CheckBox checkBox38;
        private System.Windows.Forms.CheckBox checkBox39;
        private System.Windows.Forms.CheckBox checkBox40;
        private System.Windows.Forms.CheckBox checkBox41;
        private System.Windows.Forms.CheckBox checkBox42;
        private System.Windows.Forms.CheckBox checkBox43;
        private System.Windows.Forms.CheckBox checkBox44;
        private System.Windows.Forms.CheckBox checkBox45;
        private System.Windows.Forms.CheckBox checkBox46;
        private System.Windows.Forms.CheckBox checkBox47;
        private System.Windows.Forms.CheckBox checkBox48;
        private System.Windows.Forms.CheckBox checkBox49;
        private System.Windows.Forms.CheckBox checkBox50;
        private System.Windows.Forms.CheckBox checkBox51;
        private System.Windows.Forms.CheckBox checkBox52;
        private System.Windows.Forms.CheckBox checkBox53;
        private System.Windows.Forms.CheckBox checkBox54;
        private System.Windows.Forms.CheckBox checkBox55;
        private System.Windows.Forms.CheckBox checkBox56;
        private System.Windows.Forms.CheckBox checkBox57;
        private System.Windows.Forms.CheckBox checkBox58;
        private System.Windows.Forms.CheckBox checkBox59;
        private System.Windows.Forms.CheckBox checkBox60;
        private System.Windows.Forms.CheckBox checkBox61;
        private System.Windows.Forms.CheckBox checkBox62;
        private System.Windows.Forms.CheckBox checkBox63;
        private System.Windows.Forms.CheckBox checkBox64;
        private System.Windows.Forms.CheckBox checkBox65;
        private System.Windows.Forms.CheckBox checkBox66;
        private System.Windows.Forms.CheckBox checkBox67;
        private System.Windows.Forms.CheckBox checkBox68;
        private System.Windows.Forms.CheckBox checkBox69;
        private System.Windows.Forms.CheckBox checkBox70;
        private System.Windows.Forms.CheckBox checkBox71;
        private System.Windows.Forms.CheckBox checkBox72;
        private System.Windows.Forms.CheckBox checkBox73;
        private System.Windows.Forms.CheckBox checkBox74;
        private System.Windows.Forms.CheckBox checkBox75;
        private System.Windows.Forms.CheckBox checkBox76;
        private System.Windows.Forms.CheckBox checkBox77;
        private System.Windows.Forms.CheckBox checkBox78;
        private System.Windows.Forms.CheckBox checkBox79;
        private System.Windows.Forms.CheckBox checkBox80;
        private System.Windows.Forms.CheckBox checkBox81;
        private System.Windows.Forms.CheckBox checkBox82;
        private System.Windows.Forms.CheckBox checkBox83;
        private System.Windows.Forms.CheckBox checkBox84;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lbl110;
        private System.Windows.Forms.Label lbl111;
        private System.Windows.Forms.Label lbl112;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl210;
        private System.Windows.Forms.Label lbl211;
        private System.Windows.Forms.Label lbl212;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label lbl37;
        private System.Windows.Forms.Label lbl38;
        private System.Windows.Forms.Label lbl39;
        private System.Windows.Forms.Label lbl310;
        private System.Windows.Forms.Label lbl311;
        private System.Windows.Forms.Label lbl312;
        private System.Windows.Forms.Label lbl41;
        private System.Windows.Forms.Label lbl42;
        private System.Windows.Forms.Label lbl43;
        private System.Windows.Forms.Label lbl44;
        private System.Windows.Forms.Label lbl45;
        private System.Windows.Forms.Label lbl46;
        private System.Windows.Forms.Label lbl47;
        private System.Windows.Forms.Label lbl48;
        private System.Windows.Forms.Label lbl49;
        private System.Windows.Forms.Label lbl410;
        private System.Windows.Forms.Label lbl411;
        private System.Windows.Forms.Label lbl412;
        private System.Windows.Forms.Label lbl51;
        private System.Windows.Forms.Label lbl52;
        private System.Windows.Forms.Label lbl53;
        private System.Windows.Forms.Label lbl54;
        private System.Windows.Forms.Label lbl55;
        private System.Windows.Forms.Label lbl56;
        private System.Windows.Forms.Label lbl57;
        private System.Windows.Forms.Label lbl58;
        private System.Windows.Forms.Label lbl59;
        private System.Windows.Forms.Label lbl510;
        private System.Windows.Forms.Label lbl511;
        private System.Windows.Forms.Label lbl62;
        private System.Windows.Forms.Label lbl61;
        private System.Windows.Forms.Label lbl63;
        private System.Windows.Forms.Label lbl64;
        private System.Windows.Forms.Label lbl65;
        private System.Windows.Forms.Label lbl66;
        private System.Windows.Forms.Label lbl512;
        private System.Windows.Forms.Label lbl67;
        private System.Windows.Forms.Label lbl68;
        private System.Windows.Forms.Label lbl69;
        private System.Windows.Forms.Label lbl610;
        private System.Windows.Forms.Label lbl611;
        private System.Windows.Forms.Label lbl612;
        private System.Windows.Forms.Label lbl71;
        private System.Windows.Forms.Label lbl72;
        private System.Windows.Forms.Label lbl73;
        private System.Windows.Forms.Label lbl74;
        private System.Windows.Forms.Label lbl75;
        private System.Windows.Forms.Label lbl76;
        private System.Windows.Forms.Label lbl77;
        private System.Windows.Forms.Label lbl78;
        private System.Windows.Forms.Label lbl79;
        private System.Windows.Forms.Label lbl710;
        private System.Windows.Forms.Label lbl711;
        private System.Windows.Forms.Label lbl712;
    }
}